###############################################################################################################
# POWER BI REPORT LINEAGE - System Center Orchestrator
#
# Paste this whole file into a "Run .NET Script" activity (Type: PowerShell). Nothing else needs copying.
#
# Traces every Power BI report to its semantic model, tables, and the database server, database, schema and
# table behind them. Writes an Excel workbook, a CSV, a JSON file and a run log.
#
# Replace each Required-... placeholder below with a value. Optional settings can stay empty. Instead of typing
# a value you can subscribe to one (right-click between the quotes > Subscribe), e.g. an encrypted variable for
# the client secret. Values must not contain a single quote.
###############################################################################################################

# Tenant ID or domain, e.g. contoso.onmicrosoft.com
$TenantId = 'Required-TenantId'

# The service principal's application (client) ID
$AppId = 'Required-AppId'

# The service principal's client secret. Or leave the placeholder and set CertificateThumbprint instead.
$ClientSecret = 'Required-ClientSecret-or-CertificateThumbprint'

# Folder for the output, e.g. \\fileserver\bi : each run writes PowerBI-Lineage_DDMMYYHHMM.xlsx (and .csv, .log).
# Or a file replaced on every run: \\fileserver\bi\PowerBI-Lineage.xlsx, or PowerBI-Lineage.csv for CSV only.
$ExcelPath = 'Required-ExcelPath'

# Optional: Excel = workbook and CSV (the default); CSV = CSV only, no workbook (ImportExcel module not needed)
$OutputFormat = ''

# Optional: Admin = every workspace in the tenant (the default); User = only workspaces the app belongs to
$Mode = ''

# Optional: comma-separated workspace IDs to limit the run
$WorkspaceIds = ''

# Optional: thumbprint of a certificate in LocalMachine\My, to use instead of ClientSecret
$CertificateThumbprint = ''

# Optional: stop the run after this many minutes (default 180)
$TimeoutMinutes = ''

###############################################################################################################
# Nothing below needs changing.
#
# The tool's scripts are written out in full below, as plain text: nothing is compressed or encoded.
#   1. src\modules\Prerequisites.psm1 (105 lines)
#   2. src\modules\PowerBIRest.psm1 (173 lines)
#   3. src\modules\MQueryLineage.psm1 (712 lines)
#   4. src\modules\RunProgress.psm1 (177 lines)
#   5. src\modules\LauncherArguments.psm1 (125 lines)
#   6. src\Get-PbiReportLineage.ps1 (1154 lines)
#   7. src\Export-PbiLineageWorkbook.ps1 (305 lines)
#   8. Invoke-LineageRun.ps1 (29 lines)
# On the first run they are saved to %ProgramData%\PowerBI-Lineage and run in 64-bit Windows PowerShell. The
# PowerShell modules MicrosoftPowerBIMgmt.Profile and ImportExcel (not needed for CSV only) are used where already
# installed, and installed only if missing.
###############################################################################################################

$ErrorActionPreference = 'Stop'

# A setting left empty, or left as its Required-... placeholder, is read from the matching environment variable.
function Get-Setting([string] $Typed, [string] $EnvironmentName) {
    $value = "$Typed".Trim() -replace '^Required-.*$', ''
    if (-not $value) { $value = "$([Environment]::GetEnvironmentVariable($EnvironmentName))".Trim() -replace '^Required-.*$', '' }
    $value
}

function Assert-Setting([string] $Name, [string] $Value, [string] $Pattern, [bool] $Optional) {
    if (-not $Value) {
        if ($Optional) { return }
        throw "The setting $Name is required: replace its Required-... placeholder with a value."
    }
    if ($Value -notmatch $Pattern) { throw "The setting $Name has an invalid value: $Value" }
}

$TenantId = Get-Setting $TenantId 'LINEAGE_TENANT_ID'
$AppId = Get-Setting $AppId 'LINEAGE_CLIENT_ID'
$ClientSecret = Get-Setting $ClientSecret 'PBI_CLIENT_SECRET'
$ExcelPath = Get-Setting $ExcelPath 'LINEAGE_EXCEL_PATH'
$OutputFormat = Get-Setting $OutputFormat 'LINEAGE_OUTPUT_FORMAT'
$Mode = Get-Setting $Mode 'LINEAGE_MODE'
$WorkspaceIds = (Get-Setting $WorkspaceIds 'LINEAGE_WORKSPACE_IDS') -replace '\s', ''
$CertificateThumbprint = (Get-Setting $CertificateThumbprint 'LINEAGE_CERTIFICATE_THUMBPRINT') -replace '\s', ''
$TimeoutMinutes = Get-Setting $TimeoutMinutes 'LINEAGE_TIMEOUT_MINUTES'

Assert-Setting 'TenantId' $TenantId '^[A-Za-z0-9.-]+$' $false
Assert-Setting 'AppId' $AppId '^[0-9A-Fa-f]{8}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{4}-[0-9A-Fa-f]{12}$' $false
Assert-Setting 'ExcelPath' $ExcelPath '^[^"<>|*?]+$' $false
Assert-Setting 'OutputFormat' $OutputFormat '^(Excel|CSV)$' $true
Assert-Setting 'Mode' $Mode '^(Admin|User|Auto)$' $true
Assert-Setting 'WorkspaceIds' $WorkspaceIds '^[0-9A-Fa-f-]{36}(,[0-9A-Fa-f-]{36})*$' $true
Assert-Setting 'CertificateThumbprint' $CertificateThumbprint '^[0-9A-Fa-f]{40}$' $true
Assert-Setting 'TimeoutMinutes' $TimeoutMinutes '^[0-9]{1,4}$' $true
if (-not $ClientSecret -and -not $CertificateThumbprint) { throw 'Set ClientSecret or CertificateThumbprint.' }
if (-not $Mode) { $Mode = 'Admin' }
$timeout = 180
if ($TimeoutMinutes) { $timeout = [int]$TimeoutMinutes }

# A .csv file means CSV only. A folder gets files named after this run; the CSV and log share the workbook's name.
if ($ExcelPath -match '\.csv$') { $OutputFormat = 'CSV' }
$extension = '.xlsx'
if ($OutputFormat -eq 'CSV') { $extension = '.csv' }
if ($ExcelPath -notmatch '\.(xlsx|csv)$') {
    if ((Split-Path -Leaf $ExcelPath) -match '\.[A-Za-z]{2,5}$') { throw "The setting ExcelPath must be a folder, a .xlsx file or a .csv file: $ExcelPath" }
    $ExcelPath = Join-Path $ExcelPath ('PowerBI-Lineage_' + (Get-Date).ToString('ddMMyyHHmm') + $extension)
}
# The tool writes the CSV only when given a .csv path.
$ExcelPath = [IO.Path]::ChangeExtension($ExcelPath, $extension)

# ---- The tool's files, in full ---------------------------------------------------------------------------------
# Each file is saved exactly as shown between its @' and '@ lines, with one change: a line of a file that starts
# with '@ would end the block early, so it is shown here as #~'@ and saved as '@.

$files = [ordered]@{}

# ==== File 1 of 8: src\modules\Prerequisites.psm1 (105 lines) ===================================================
$files['src\modules\Prerequisites.psm1'] = @'
#Requires -Version 5.1
<#
.SYNOPSIS
    Makes sure the PowerShell modules a script needs are present, installing them for the current user only if not.

.DESCRIPTION
    A module that is already installed is used as it is, never installed again. It is looked for in this
    PowerShell's module folders first, then in the module folders of the other Windows PowerShell (32-bit or 64-bit),
    so a module installed for one of them, e.g. for a System Center Orchestrator runbook, is found by the other.

    Only a module found nowhere is installed, into the current user's module folder, so no administrator rights are
    needed. Works in Windows PowerShell 5.1 (bootstrapping the NuGet provider and TLS 1.2 it needs to reach the
    PowerShell Gallery) and in PowerShell 7.
#>

function Get-OtherModuleFolder {
    # Windows PowerShell module folders for all users and the current user, in both 64-bit and 32-bit form, then
    # the folders modules installed from PowerShell 7 go to (not PowerShell 7's own built-in modules).
    if (-not $env:SystemRoot) { return }
    $documents = [Environment]::GetFolderPath('MyDocuments')
    $programFiles = @($env:ProgramW6432, $env:ProgramFiles, ${env:ProgramFiles(x86)}) | Where-Object { $_ }
    $folders = @(
        foreach ($root in $programFiles) { Join-Path $root 'WindowsPowerShell\Modules' }
        foreach ($system in 'System32', 'Sysnative', 'SysWOW64') { Join-Path $env:SystemRoot "$system\WindowsPowerShell\v1.0\Modules" }
        if ($documents) { Join-Path $documents 'WindowsPowerShell\Modules' }
        foreach ($root in $programFiles) { Join-Path $root 'PowerShell\Modules' }
        if ($documents) { Join-Path $documents 'PowerShell\Modules' }
    )
    $folders | Where-Object { Test-Path -LiteralPath $_ } | Select-Object -Unique
}

function Add-OtherModuleFolder {
    # Appends the folders this PowerShell does not already search, for this process only. Returns $true if any were added.
    $current = @($env:PSModulePath -split ';' | Where-Object { $_ } | ForEach-Object { $_.TrimEnd('\') })
    $added = @(Get-OtherModuleFolder | Where-Object { $current -notcontains $_.TrimEnd('\') })
    if ($added.Count -eq 0) { return $false }
    $env:PSModulePath = (@($current) + $added) -join ';'
    $true
}

function Find-RequiredModule {
    <#
    .SYNOPSIS
        Returns the newest installed copy of a module (at least MinimumVersion), or nothing if it is not installed.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string] $Name,
        [version] $MinimumVersion
    )
    for ($attempt = 1; $attempt -le 2; $attempt++) {
        $found = Get-Module -ListAvailable -Name $Name |
            Where-Object { -not $MinimumVersion -or $_.Version -ge $MinimumVersion } |
            Sort-Object Version -Descending |
            Select-Object -First 1
        if ($found) { return $found }
        # Not in this PowerShell's folders: look in the other Windows PowerShell's folders once.
        if ($attempt -eq 1 -and -not (Add-OtherModuleFolder)) { return }
    }
}

function Initialize-RequiredModule {
    <#
    .SYNOPSIS
        Imports a module. Installs it from the PowerShell Gallery for the current user first, only if it is not installed.
    .EXAMPLE
        Initialize-RequiredModule -Name ImportExcel
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string] $Name,
        [version] $MinimumVersion
    )
    if (-not (Find-RequiredModule -Name $Name -MinimumVersion $MinimumVersion)) {
        Write-Information "Installing the $Name PowerShell module for your user account (first run only)..."
        $ProgressPreference = 'SilentlyContinue'
        try {
            # Windows PowerShell 5.1 defaults to TLS 1.0/1.1, which the PowerShell Gallery refuses.
            [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

            $nuget = Get-PackageProvider -ListAvailable -ErrorAction SilentlyContinue |
                Where-Object { $_.Name -eq 'NuGet' -and $_.Version -ge [version]'2.8.5.201' }
            if (-not $nuget) {
                $null = Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Scope CurrentUser -Force -ErrorAction Stop
            }

            $install = @{ Name = $Name; Scope = 'CurrentUser'; Repository = 'PSGallery'; Force = $true; ErrorAction = 'Stop' }
            if ($MinimumVersion) { $install.MinimumVersion = $MinimumVersion }
            Install-Module @install
        }
        catch {
            $account = [Security.Principal.WindowsIdentity]::GetCurrent().Name
            throw ("The $Name module is not installed on $env:COMPUTERNAME for $account, and installing it from the " +
                "PowerShell Gallery failed: $($_.Exception.Message) " +
                "Install it once for all users in an elevated Windows PowerShell: Install-Module $Name -Scope AllUsers " +
                "(or ask IT to allow powershellgallery.com, or to install it).")
        }
    }

    $import = @{ Name = $Name; ErrorAction = 'Stop'; WarningAction = 'SilentlyContinue' }
    if ($MinimumVersion) { $import.MinimumVersion = $MinimumVersion }
    Import-Module @import
}

Export-ModuleMember -Function Find-RequiredModule, Initialize-RequiredModule
'@

# ==== File 2 of 8: src\modules\PowerBIRest.psm1 (173 lines) =====================================================
$files['src\modules\PowerBIRest.psm1'] = @'
#Requires -Version 5.1
<#
.SYNOPSIS
    Power BI REST helpers: authenticated calls with throttling retry, paging, and the admin scanner workflow.

.DESCRIPTION
    Uses the token from the current MicrosoftPowerBIMgmt session (Connect-PowerBIServiceAccount), so interactive
    and service principal sign-in both work. Calls go through Invoke-RestMethod rather than
    Invoke-PowerBIRestMethod so that 429 Retry-After headers and error bodies are visible.

    Runs in Windows PowerShell 5.1 and PowerShell 7. Failed calls throw an exception whose Data['StatusCode']
    holds the HTTP status.
#>

# Windows PowerShell 5.1 defaults to TLS 1.0/1.1; Power BI requires TLS 1.2.
[Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12

$script:ApiBaseUrl = 'https://api.powerbi.com/v1.0/myorg'
# Get-PowerBIAccessToken comes from MicrosoftPowerBIMgmt.Profile, which callers load with Initialize-RequiredModule.

function Set-PbiApiBaseUrl {
    <#
    .SYNOPSIS
        Overrides the API root, for sovereign clouds (e.g. https://api.powerbigov.us/v1.0/myorg).
    #>
    [CmdletBinding()]
    param([Parameter(Mandatory)][string] $Url)
    $script:ApiBaseUrl = $Url.TrimEnd('/')
}

function Invoke-PbiRestMethod {
    <#
    .SYNOPSIS
        Calls a Power BI REST endpoint, retrying on 429 and 5xx.
    .PARAMETER Path
        Path relative to the API root (e.g. 'groups'), or an absolute https URL.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string] $Path,
        [ValidateSet('Get', 'Post')][string] $Method = 'Get',
        [object] $Body,
        [int] $MaxRetries = 6
    )
    # Invoke-RestMethod's progress bar is noise here and makes Windows PowerShell 5.1 requests much slower.
    $ProgressPreference = 'SilentlyContinue'
    $uri = if ($Path -match '^https?://') { $Path } else { '{0}/{1}' -f $script:ApiBaseUrl, $Path.TrimStart('/') }
    # Assigned directly: an if-expression would unroll the byte array into object[] and corrupt the body.
    $bodyBytes = $null
    if ($null -ne $Body) { $bodyBytes = [Text.Encoding]::UTF8.GetBytes(($Body | ConvertTo-Json -Depth 20 -Compress)) }

    for ($attempt = 0; ; $attempt++) {
        $request = @{
            Uri             = $uri
            Method          = $Method
            Headers         = @{ Authorization = (Get-PowerBIAccessToken -AsString) }
            UseBasicParsing = $true
        }
        if ($bodyBytes) {
            $request.Body = $bodyBytes
            $request.ContentType = 'application/json; charset=utf-8'
        }

        try {
            return Invoke-RestMethod @request
        }
        catch {
            # 5.1 surfaces an HttpWebResponse, PowerShell 7 an HttpResponseMessage; both carry StatusCode.
            $response = $_.Exception.Response
            if ($null -eq $response) { throw }
            $status = [int]$response.StatusCode
            $errorBody = $_.ErrorDetails.Message
            if (-not $errorBody -and $response -is [System.Net.HttpWebResponse]) {
                try { $errorBody = [IO.StreamReader]::new($response.GetResponseStream()).ReadToEnd() }
                catch { Write-Verbose "Could not read the error response body: $($_.Exception.Message)" }
            }
            $retryAfter = if ($response.Headers -is [System.Net.WebHeaderCollection]) { $response.Headers['Retry-After'] }
            elseif ($response.Headers.RetryAfter.Delta) { $response.Headers.RetryAfter.Delta.TotalSeconds }
        }

        $retryable = $status -eq 429 -or $status -ge 500
        if (-not $retryable -or $attempt -ge $MaxRetries) {
            $detail = $errorBody
            try {
                $parsed = $errorBody | ConvertFrom-Json -ErrorAction Stop
                # executeQueries puts the readable reason in error.pbi.error.details[].detail.value.
                $pbiDetails = @($parsed.error.'pbi.error'.details | Where-Object { $_ } | ForEach-Object {
                        if ($_.detail.value) { $_.detail.value } elseif ($_.message) { $_.message }
                    })
                if ($parsed.error.message) { $detail = $parsed.error.message }
                elseif ($pbiDetails.Count -gt 0) { $detail = $pbiDetails -join ' ' }
                elseif ($parsed.error.code) { $detail = $parsed.error.code }
                elseif ($parsed.Message) { $detail = $parsed.Message }
            }
            catch { Write-Verbose 'Error body is not JSON.' }
            if (-not $detail) { $detail = if ($response.ReasonPhrase) { $response.ReasonPhrase } else { $response.StatusDescription } }
            if ($detail -and $detail.Length -gt 1000) { $detail = $detail.Substring(0, 1000) }
            $shownPath = if ($uri.StartsWith("$script:ApiBaseUrl/")) { $uri.Substring($script:ApiBaseUrl.Length + 1) } else { $uri }
            $exception = [System.InvalidOperationException]::new("HTTP $status from $($Method.ToUpperInvariant()) ${shownPath}: $detail")
            $exception.Data['StatusCode'] = $status
            throw $exception
        }

        $delay = [math]::Min(60, [math]::Pow(2, $attempt + 1))
        if ($retryAfter -as [int]) { $delay = [int]$retryAfter }
        Write-Verbose "HTTP $status from $uri; retrying in $delay s (attempt $($attempt + 1) of $MaxRetries)."
        Start-Sleep -Seconds $delay
    }
}

function Get-PbiPagedValue {
    <#
    .SYNOPSIS
        Returns every item from an endpoint that pages with $top / $skip and wraps results in 'value'.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string] $Path,
        [int] $PageSize = 5000
    )
    $skip = 0
    do {
        $separator = if ($Path.Contains('?')) { '&' } else { '?' }
        $page = Invoke-PbiRestMethod -Path ('{0}{1}$top={2}&$skip={3}' -f $Path, $separator, $PageSize, $skip)
        $items = @($page.value | Where-Object { $_ })
        $items
        $skip += $PageSize
    } while ($items.Count -eq $PageSize)
}

function Invoke-PbiWorkspaceScan {
    <#
    .SYNOPSIS
        Runs the admin scanner (WorkspaceInfo) over workspaces in batches and emits one scan result per batch.
    .DESCRIPTION
        Requests lineage, data source details, dataset schema and dataset expressions. Table and expression
        metadata only comes back when the tenant settings "Enhance admin APIs responses with detailed metadata"
        and "Enhance admin APIs responses with DAX and mashup expressions" are enabled.
    .PARAMETER OnProgress
        Optional script block called with a short status text ("batch 2 of 5, scanning") while batches run.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][string[]] $WorkspaceId,
        [ValidateRange(1, 100)][int] $BatchSize = 100,
        [int] $PollSeconds = 5,
        [int] $TimeoutMinutes = 30,
        [scriptblock] $OnProgress
    )
    $query = 'lineage=True&datasourceDetails=True&datasetSchema=True&datasetExpressions=True&getArtifactUsers=False'
    $batchCount = [math]::Ceiling($WorkspaceId.Count / $BatchSize)

    for ($batch = 0; $batch -lt $batchCount; $batch++) {
        $ids = @($WorkspaceId | Select-Object -Skip ($batch * $BatchSize) -First $BatchSize)
        $label = "batch $($batch + 1) of $batchCount"
        if ($OnProgress) { & $OnProgress "$label, starting" }

        $scan = Invoke-PbiRestMethod -Method Post -Path "admin/workspaces/getInfo?$query" -Body @{ workspaces = $ids }
        $deadline = (Get-Date).AddMinutes($TimeoutMinutes)
        do {
            Start-Sleep -Seconds $PollSeconds
            $state = Invoke-PbiRestMethod -Path "admin/workspaces/scanStatus/$($scan.id)"
            if ($OnProgress) { & $OnProgress "$label, $($state.status.ToLowerInvariant())" }
            if ((Get-Date) -gt $deadline) { throw "Scan $($scan.id) did not finish within $TimeoutMinutes minutes." }
        } while ($state.status -in 'NotStarted', 'Running')

        if ($state.status -ne 'Succeeded') { throw "Scan $($scan.id) ended with status '$($state.status)'." }
        if ($OnProgress) { & $OnProgress "$label, downloading" }
        Invoke-PbiRestMethod -Path "admin/workspaces/scanResult/$($scan.id)"
    }
}

Export-ModuleMember -Function Set-PbiApiBaseUrl, Invoke-PbiRestMethod, Get-PbiPagedValue, Invoke-PbiWorkspaceScan
'@

# ==== File 3 of 8: src\modules\MQueryLineage.psm1 (712 lines) ===================================================
$files['src\modules\MQueryLineage.psm1'] = @'
#Requires -Version 5.1
<#
.SYNOPSIS
    Static analysis of Power Query (M) expressions: finds the upstream server, database, schema and
    table/view that a Power BI model table reads from.

.DESCRIPTION
    Power BI does not store "which database table feeds this model table" as a field. It stores the M
    expression behind each table. This module tokenises that expression, walks its let-steps and any shared
    expressions (queries and parameters) it references, and returns:

      - the connector call, e.g. Sql.Database("server", "database")
      - the navigation steps that pick an object, e.g. Source{[Schema="dbo", Item="FactSales"]}[Data]
      - any native SQL, e.g. [Query="SELECT ..."] or Value.NativeQuery(...), with the tables it references

    It reads the expression; it does not evaluate it. Anything computed at refresh time (function results,
    dynamic navigation, text built from other queries) is reported as unresolved, never guessed. Parameters
    that cannot be resolved appear as {ParameterName}.
#>

$script:TokenPattern = [regex]::new(@'
  (?<ws>\s+)
| (?<comment>//[^\r\n]*|/\*.*?\*/)
| (?<qid>\#"(?:[^"]|"")*")
| (?<str>"(?:[^"]|"")*")
| (?<num>\d+(?:\.\d+)?(?:[eE][+-]?\d+)?)
| (?<id>\#?[\p{L}_][\p{L}\p{Nd}_]*(?:\.[\p{L}_][\p{L}\p{Nd}_]*)*)
| (?<sym>=>|<>|<=|>=|\.\.\.?|\S)
#~'@, 'IgnorePatternWhitespace, Singleline, Compiled')

$script:MEscapeEvaluator = [System.Text.RegularExpressions.MatchEvaluator] {
    param($match)
    $builder = [System.Text.StringBuilder]::new()
    foreach ($code in $match.Groups[1].Value.Split(',')) {
        $c = $code.Trim()
        if ($c -ceq 'cr') { [void]$builder.Append("`r") }
        elseif ($c -ceq 'lf') { [void]$builder.Append("`n") }
        elseif ($c -ceq 'tab') { [void]$builder.Append("`t") }
        elseif ($c -eq '#') { [void]$builder.Append('#') }
        elseif ($c -match '^(?:[0-9A-Fa-f]{4}|[0-9A-Fa-f]{8})$') {
            [void]$builder.Append([char]::ConvertFromUtf32([Convert]::ToInt32($c, 16)))
        }
        else { return $match.Value }
    }
    $builder.ToString()
}

$script:Keywords = [System.Collections.Generic.HashSet[string]]::new(
    [string[]]@('let', 'in', 'each', 'if', 'then', 'else', 'and', 'or', 'not', 'true', 'false', 'null', 'meta',
        'type', 'as', 'is', 'otherwise', 'try', 'error', 'section', 'shared'),
    [System.StringComparer]::Ordinal)

# Argument roles: Server, Database, Object, Location and NativeQuery map to output fields; any other role
# name (HttpPath, Warehouse) is kept as a connector option.
$script:ConnectorCatalog = @{
    'Sql.Database'                  = @{ SourceType = 'SQL Server'; Arguments = @('Server', 'Database') }
    'Sql.Databases'                 = @{ SourceType = 'SQL Server'; Arguments = @('Server') }
    'Oracle.Database'               = @{ SourceType = 'Oracle'; Arguments = @('Server') }
    'PostgreSQL.Database'           = @{ SourceType = 'PostgreSQL'; Arguments = @('Server', 'Database') }
    'MySQL.Database'                = @{ SourceType = 'MySQL'; Arguments = @('Server', 'Database') }
    'AmazonRedshift.Database'       = @{ SourceType = 'Amazon Redshift'; Arguments = @('Server', 'Database') }
    'Snowflake.Databases'           = @{ SourceType = 'Snowflake'; Arguments = @('Server', 'Warehouse') }
    'GoogleBigQuery.Database'       = @{ SourceType = 'Google BigQuery'; Arguments = @() }
    'Databricks.Catalogs'           = @{ SourceType = 'Databricks'; Arguments = @('Server', 'HttpPath') }
    'Databricks.Contents'           = @{ SourceType = 'Databricks'; Arguments = @('Server', 'HttpPath') }
    'DatabricksMultiCloud.Catalogs' = @{ SourceType = 'Databricks'; Arguments = @('Server', 'HttpPath') }
    'Teradata.Database'             = @{ SourceType = 'Teradata'; Arguments = @('Server') }
    'DB2.Database'                  = @{ SourceType = 'IBM Db2'; Arguments = @('Server', 'Database') }
    'SapHana.Database'              = @{ SourceType = 'SAP HANA'; Arguments = @('Server') }
    'SapBusinessWarehouse.Cubes'    = @{ SourceType = 'SAP BW'; Arguments = @('Server') }
    'Sybase.Database'               = @{ SourceType = 'Sybase'; Arguments = @('Server', 'Database') }
    'Informix.Database'             = @{ SourceType = 'Informix'; Arguments = @('Server', 'Database') }
    'AnalysisServices.Database'     = @{ SourceType = 'Analysis Services'; Arguments = @('Server', 'Database') }
    'AnalysisServices.Databases'    = @{ SourceType = 'Analysis Services'; Arguments = @('Server') }
    'AzureDataExplorer.Contents'    = @{ SourceType = 'Azure Data Explorer'; Arguments = @('Server', 'Database', 'Object') }
    'Kusto.Contents'                = @{ SourceType = 'Azure Data Explorer'; Arguments = @('Server', 'Database', 'Object') }
    'Odbc.DataSource'               = @{ SourceType = 'ODBC'; Arguments = @('Server') }
    'Odbc.Query'                    = @{ SourceType = 'ODBC'; Arguments = @('Server', 'NativeQuery') }
    'OleDb.DataSource'              = @{ SourceType = 'OLE DB'; Arguments = @('Server') }
    'OleDb.Query'                   = @{ SourceType = 'OLE DB'; Arguments = @('Server', 'NativeQuery') }
    'OData.Feed'                    = @{ SourceType = 'OData'; Arguments = @('Location') }
    'Web.Contents'                  = @{ SourceType = 'Web'; Arguments = @('Location') }
    'SharePoint.Files'              = @{ SourceType = 'SharePoint'; Arguments = @('Location') }
    'SharePoint.Contents'           = @{ SourceType = 'SharePoint'; Arguments = @('Location') }
    'SharePoint.Tables'             = @{ SourceType = 'SharePoint list'; Arguments = @('Location') }
    'File.Contents'                 = @{ SourceType = 'File'; Arguments = @('Location') }
    'Folder.Files'                  = @{ SourceType = 'Folder'; Arguments = @('Location') }
    'Folder.Contents'               = @{ SourceType = 'Folder'; Arguments = @('Location') }
    'AzureStorage.Blobs'            = @{ SourceType = 'Azure Blob Storage'; Arguments = @('Location') }
    'AzureStorage.DataLake'         = @{ SourceType = 'Azure Data Lake Storage'; Arguments = @('Location') }
    'AzureStorage.Tables'           = @{ SourceType = 'Azure Table Storage'; Arguments = @('Location') }
    'Lakehouse.Contents'            = @{ SourceType = 'Fabric Lakehouse'; Arguments = @() }
    'Fabric.Warehouse'              = @{ SourceType = 'Fabric Warehouse'; Arguments = @() }
    'PowerPlatform.Dataflows'       = @{ SourceType = 'Dataflow'; Arguments = @() }
    'PowerBI.Dataflows'             = @{ SourceType = 'Dataflow'; Arguments = @() }
    'CommonDataService.Database'    = @{ SourceType = 'Dataverse'; Arguments = @('Server') }
    'Dataverse.Contents'            = @{ SourceType = 'Dataverse'; Arguments = @() }
    'Salesforce.Data'               = @{ SourceType = 'Salesforce'; Arguments = @('Location') }
}

# Library namespaces whose *.Contents / *.Tables / ... functions transform data rather than connect to a source.
$script:NonSourceNamespaces = [System.Collections.Generic.HashSet[string]]::new(
    [string[]]@('Table', 'List', 'Record', 'Text', 'Number', 'Date', 'DateTime', 'DateTimeZone', 'Duration', 'Time',
        'Binary', 'BinaryFormat', 'Value', 'Expression', 'Function', 'Type', 'Json', 'Csv', 'Excel', 'Xml', 'Lines',
        'Splitter', 'Combiner', 'Replacer', 'Comparer', 'Cube', 'Uri', 'Html', 'Pdf', 'Parquet', 'Access',
        'Character', 'Logical', 'Diagnostics', 'Error', 'Variable', 'Embedded', 'Action', 'Culture'),
    [System.StringComparer]::OrdinalIgnoreCase)

$script:SharedContextCache = $null

#region Tokenising

function ConvertFrom-MStringLiteral {
    param([string] $Literal)
    $inner = $Literal.Substring(1, $Literal.Length - 2).Replace('""', '"')
    [regex]::Replace($inner, '#\(([^)]*)\)', $script:MEscapeEvaluator)
}

function Get-MToken {
    param([AllowEmptyString()][string] $Expression)
    $tokens = [System.Collections.Generic.List[object]]::new()
    foreach ($m in $script:TokenPattern.Matches($Expression)) {
        if ($m.Groups['ws'].Success -or $m.Groups['comment'].Success) { continue }
        $token = if ($m.Groups['str'].Success) {
            [pscustomobject]@{ Type = 'String'; Value = ConvertFrom-MStringLiteral $m.Value; Quoted = $false }
        }
        elseif ($m.Groups['qid'].Success) {
            $name = $m.Value.Substring(2, $m.Value.Length - 3).Replace('""', '"')
            [pscustomobject]@{ Type = 'Identifier'; Value = $name; Quoted = $true }
        }
        elseif ($m.Groups['id'].Success) { [pscustomobject]@{ Type = 'Identifier'; Value = $m.Value; Quoted = $false } }
        elseif ($m.Groups['num'].Success) { [pscustomobject]@{ Type = 'Number'; Value = $m.Value; Quoted = $false } }
        else { [pscustomobject]@{ Type = 'Symbol'; Value = $m.Value; Quoted = $false } }
        $tokens.Add($token)
    }
    , $tokens
}

function Test-MSymbol {
    param($Token, [string[]] $Value)
    $null -ne $Token -and $Token.Type -eq 'Symbol' -and $Value -contains $Token.Value
}

function Test-MKeyword {
    param($Token, [string] $Keyword)
    $null -ne $Token -and $Token.Type -eq 'Identifier' -and -not $Token.Quoted -and $Token.Value -ceq $Keyword
}

function Get-MTokenRange {
    param([System.Collections.Generic.List[object]] $Tokens, [int] $From, [int] $To)
    if ($To -lt $From) { return , [System.Collections.Generic.List[object]]::new() }
    , $Tokens.GetRange($From, $To - $From + 1)
}

#endregion

#region Structure: let-steps, call arguments, records

function Split-MLetExpression {
    param([System.Collections.Generic.List[object]] $Tokens)
    $steps = [System.Collections.Generic.List[object]]::new()
    if ($Tokens.Count -eq 0 -or -not (Test-MKeyword $Tokens[0] 'let')) {
        return [pscustomobject]@{ Steps = $steps; Result = $Tokens }
    }

    $addStep = {
        param([int] $From, [int] $To)
        $segment = Get-MTokenRange $Tokens $From $To
        if ($segment.Count -ge 3 -and $segment[0].Type -eq 'Identifier' -and (Test-MSymbol $segment[1] '=')) {
            $steps.Add([pscustomobject]@{ Name = $segment[0].Value; Body = (Get-MTokenRange $segment 2 ($segment.Count - 1)) })
        }
    }

    $depth = 0
    $letDepth = 1
    $start = 1
    for ($k = 1; $k -lt $Tokens.Count; $k++) {
        $t = $Tokens[$k]
        if (Test-MSymbol $t '(', '[', '{') { $depth++ }
        elseif (Test-MSymbol $t ')', ']', '}') { $depth-- }
        elseif ($depth -eq 0 -and $letDepth -eq 1 -and (Test-MSymbol $t ',')) {
            & $addStep $start ($k - 1)
            $start = $k + 1
        }
        elseif ($depth -eq 0 -and (Test-MKeyword $t 'let')) { $letDepth++ }
        elseif ($depth -eq 0 -and (Test-MKeyword $t 'in')) {
            $letDepth--
            if ($letDepth -eq 0) {
                & $addStep $start ($k - 1)
                return [pscustomobject]@{ Steps = $steps; Result = (Get-MTokenRange $Tokens ($k + 1) ($Tokens.Count - 1)) }
            }
        }
    }
    & $addStep $start ($Tokens.Count - 1)
    [pscustomobject]@{ Steps = $steps; Result = [System.Collections.Generic.List[object]]::new() }
}

function Get-MCallArgument {
    param([System.Collections.Generic.List[object]] $Tokens, [int] $OpenIndex)
    $arguments = [System.Collections.Generic.List[object]]::new()
    $current = [System.Collections.Generic.List[object]]::new()
    $depth = 0
    for ($k = $OpenIndex; $k -lt $Tokens.Count; $k++) {
        $t = $Tokens[$k]
        if (Test-MSymbol $t '(', '[', '{') {
            $depth++
            if ($depth -eq 1) { continue }
        }
        elseif (Test-MSymbol $t ')', ']', '}') {
            $depth--
            if ($depth -eq 0) { break }
        }
        elseif ($depth -eq 1 -and (Test-MSymbol $t ',')) {
            $arguments.Add($current)
            $current = [System.Collections.Generic.List[object]]::new()
            continue
        }
        $current.Add($t)
    }
    if ($current.Count -gt 0) { $arguments.Add($current) }
    , $arguments
}

function ConvertFrom-MRecord {
    # Reads the record literal starting at $OpenIndex ('[') into a hashtable of field -> resolved text value.
    param([System.Collections.Generic.List[object]] $Tokens, [int] $OpenIndex, $Scope, $Context)
    $fields = @{}
    foreach ($field in (Get-MCallArgument $Tokens $OpenIndex)) {
        if ($field.Count -ge 3 -and $field[0].Type -eq 'Identifier' -and (Test-MSymbol $field[1] '=')) {
            $fields[$field[0].Value] = Resolve-MValue (Get-MTokenRange $field 2 ($field.Count - 1)) $Scope $Context
        }
    }
    $fields
}

function Get-MNavigationRecord {
    # Indexer navigation: <expression>{[Schema="dbo", Item="Sales"]}. A list literal ({[...]} after '(' or ',')
    # is not navigation, so the token before '{' must end an expression.
    param([System.Collections.Generic.List[object]] $Tokens, $Scope, $Context)
    for ($k = 1; $k -lt $Tokens.Count - 1; $k++) {
        if (-not (Test-MSymbol $Tokens[$k] '{') -or -not (Test-MSymbol $Tokens[$k + 1] '[')) { continue }
        $previous = $Tokens[$k - 1]
        $endsExpression = (Test-MSymbol $previous ']', ')', '}') -or
            ($previous.Type -eq 'Identifier' -and ($previous.Quoted -or -not $script:Keywords.Contains($previous.Value)))
        if (-not $endsExpression) { continue }
        $fields = ConvertFrom-MRecord $Tokens ($k + 1) $Scope $Context
        if ($fields.Count -gt 0) { $fields }
    }
}

#endregion

#region Values and references

function Test-MParameter {
    param([string] $Name, $Context)
    if (-not $Context.Shared.ContainsKey($Name)) { return $false }
    $Context.Shared[$Name] -match 'IsParameterQuery\s*=\s*true'
}

function Get-MSharedToken {
    param([string] $Name, $Context)
    if (-not $Context.SharedTokens.ContainsKey($Name)) {
        $Context.SharedTokens[$Name] = Get-MToken $Context.Shared[$Name]
    }
    , $Context.SharedTokens[$Name]
}

function Resolve-MValue {
    # Resolves a text-valued M expression: literals, parameters, text steps and '&' concatenation.
    # Returns $null when the value is computed at refresh time.
    param([System.Collections.Generic.List[object]] $Tokens, $Scope, $Context, [int] $Depth = 0)
    if ($null -eq $Tokens -or $Tokens.Count -eq 0 -or $Depth -gt 10) { return $null }

    $parts = [System.Collections.Generic.List[object]]::new()
    $current = [System.Collections.Generic.List[object]]::new()
    $nesting = 0
    foreach ($t in $Tokens) {
        if (Test-MSymbol $t '(', '[', '{') { $nesting++ }
        elseif (Test-MSymbol $t ')', ']', '}') { $nesting-- }
        elseif ($nesting -eq 0 -and (Test-MSymbol $t '&')) {
            $parts.Add($current)
            $current = [System.Collections.Generic.List[object]]::new()
            continue
        }
        $current.Add($t)
    }
    $parts.Add($current)

    $builder = [System.Text.StringBuilder]::new()
    foreach ($part in $parts) {
        # "value" meta [IsParameterQuery=true, ...] is how a parameter stores its current value.
        if ($part.Count -ge 2 -and $part[0].Type -eq 'String' -and (Test-MKeyword $part[1] 'meta')) {
            [void]$builder.Append($part[0].Value)
            continue
        }
        if ($part.Count -ne 1) { return $null }
        $t = $part[0]
        switch ($t.Type) {
            'String' { [void]$builder.Append($t.Value) }
            'Number' { [void]$builder.Append($t.Value) }
            'Identifier' {
                if (Test-MKeyword $t 'null') { return $null }
                $resolved = $null
                if ($null -ne $Scope -and $Scope.Steps.ContainsKey($t.Value)) {
                    $resolved = Resolve-MValue $Scope.Steps[$t.Value] $Scope $Context ($Depth + 1)
                }
                elseif ($Context.Shared.ContainsKey($t.Value)) {
                    $resolved = Resolve-MValue (Get-MSharedToken $t.Value $Context) $null $Context ($Depth + 1)
                }
                if ($null -eq $resolved) { $resolved = '{' + $t.Value + '}' }
                [void]$builder.Append($resolved)
            }
            default { return $null }
        }
    }
    $builder.ToString()
}

function Get-MReference {
    # Names of local steps or shared queries referenced by a step. Parameters are values, not sources, so
    # they are excluded; record field names and [Column] accessors are not references.
    param([System.Collections.Generic.List[object]] $Tokens, $Scope, $Context)
    $seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::Ordinal)
    $bracketDepth = 0
    for ($k = 0; $k -lt $Tokens.Count; $k++) {
        $t = $Tokens[$k]
        if (Test-MSymbol $t '[') { $bracketDepth++; continue }
        if (Test-MSymbol $t ']') { $bracketDepth--; continue }
        if ($t.Type -ne 'Identifier') { continue }
        if (-not $t.Quoted -and $script:Keywords.Contains($t.Value)) { continue }
        if ($bracketDepth -gt 0) {
            $next = if ($k + 1 -lt $Tokens.Count) { $Tokens[$k + 1] }
            $previous = if ($k -gt 0) { $Tokens[$k - 1] }
            if ((Test-MSymbol $next '=') -or ((Test-MSymbol $previous '[') -and (Test-MSymbol $next ']'))) { continue }
        }
        $name = $t.Value
        $isReference = $Scope.Steps.ContainsKey($name) -or
            ($Context.Shared.ContainsKey($name) -and -not (Test-MParameter $name $Context))
        if ($isReference -and $seen.Add($name)) { $name }
    }
}

#endregion

#region Sources

function New-MSource {
    param([string] $Connector, [string] $SourceType)
    @{
        Connector = $Connector; SourceType = $SourceType
        Server = ''; Database = ''; Schema = ''; Object = ''; ObjectKind = ''; ObjectOrigin = ''
        Location = ''; NativeQuery = ''; Options = @{}
    }
}

function Copy-MSource {
    param([hashtable] $Source)
    $copy = $Source.Clone()
    $copy.Options = $Source.Options.Clone()
    $copy
}

function Get-MConnectorDefinition {
    param([string] $Name)
    if ($script:ConnectorCatalog.ContainsKey($Name)) { return $script:ConnectorCatalog[$Name] }
    if ($Name -cmatch '^([A-Za-z0-9]+)\.(Database|Databases|Contents|Feed|DataSource|Catalogs|Tables|Files|Data|Query)$' -and
        -not $script:NonSourceNamespaces.Contains($Matches[1])) {
        return @{ SourceType = $Matches[1]; Arguments = @('Server') }
    }
}

function New-MSourceFromCall {
    param([string] $Name, [hashtable] $Definition, $Arguments, $Scope, $Context)
    $source = New-MSource -Connector $Name -SourceType $Definition.SourceType
    for ($i = 0; $i -lt $Definition.Arguments.Count -and $i -lt $Arguments.Count; $i++) {
        $value = Resolve-MValue $Arguments[$i] $Scope $Context
        if ($null -eq $value) { continue }
        $role = $Definition.Arguments[$i]
        if ($role -in 'Server', 'Database', 'Object', 'Location', 'NativeQuery') { $source[$role] = $value }
        else { $source.Options[$role] = $value }
    }
    foreach ($argument in $Arguments) {
        if ($argument.Count -gt 0 -and (Test-MSymbol $argument[0] '[')) {
            $options = ConvertFrom-MRecord $argument 0 $Scope $Context
            if ($options['Query']) { $source.NativeQuery = $options['Query'] }
        }
    }
    $source
}

function Set-MNavigation {
    param([hashtable] $Source, [hashtable] $Fields)
    if ($Source.Object) { return }
    $kind = [string]$(if ($Fields.ContainsKey('Kind')) { $Fields['Kind'] } elseif ($Fields.ContainsKey('ItemKind')) { $Fields['ItemKind'] })

    # Dataflow and Fabric item navigation: workspace > item > entity/table.
    if ($Fields['workspaceId'] -and -not $Source.Server) { $Source.Server = $Fields['workspaceId'] }
    foreach ($key in 'lakehouseId', 'warehouseId', 'dataflowId', 'datasetId', 'databaseId') {
        if ($Fields[$key]) { $Source.Database = $Fields[$key] }
    }
    if ($Fields['entity']) { $Source.Object = $Fields['entity']; $Source.ObjectKind = 'Entity' }

    if ($Fields.ContainsKey('Schema') -and $Fields['Schema']) { $Source.Schema = $Fields['Schema'] }
    if ($Fields.ContainsKey('Item') -and $Fields['Item']) {
        $Source.Object = $Fields['Item']
        $Source.ObjectKind = $kind
    }
    elseif ($Fields.ContainsKey('Name') -and $Fields['Name']) {
        $name = $Fields['Name']
        switch -Regex ($kind) {
            '^(Database|Catalog)$' { $Source.Database = $name; break }
            '^Schema$' { $Source.Schema = $name; break }
            '^$' {
                if (-not $Source.Database -and $Source.Connector -match '\.(Databases|Catalogs)$') { $Source.Database = $name }
                else { $Source.Object = $name }
                break
            }
            default { $Source.Object = $name; $Source.ObjectKind = $kind }
        }
    }
    elseif ($Fields.ContainsKey('Id') -and $Fields['Id'] -and $kind) {
        if ($kind -match '^(Lakehouse|Warehouse|Database)$') { $Source.Database = $Fields['Id'] }
        else { $Source.Object = $Fields['Id']; $Source.ObjectKind = $kind }
    }
}

function Resolve-MStepSource {
    param([string] $Name, $Scope, $Context)
    $result = [System.Collections.Generic.List[hashtable]]::new()
    if (-not $Scope.Cache.ContainsKey($Name)) {
        if (-not $Scope.Resolving.Add($Name)) { return , $result }

        $tokens = $Scope.Steps[$Name]
        $sources = [System.Collections.Generic.List[hashtable]]::new()
        $nativeQueries = [System.Collections.Generic.List[string]]::new()

        for ($k = 0; $k -lt $tokens.Count - 1; $k++) {
            $t = $tokens[$k]
            if ($t.Type -ne 'Identifier' -or $t.Quoted -or -not (Test-MSymbol $tokens[$k + 1] '(')) { continue }
            if ($t.Value -ceq 'Value.NativeQuery') {
                $callArguments = Get-MCallArgument $tokens ($k + 1)
                if ($callArguments.Count -ge 2) {
                    $query = Resolve-MValue $callArguments[1] $Scope $Context
                    if ($query) { $nativeQueries.Add($query) }
                }
                continue
            }
            $definition = Get-MConnectorDefinition $t.Value
            if ($definition) {
                $sources.Add((New-MSourceFromCall $t.Value $definition (Get-MCallArgument $tokens ($k + 1)) $Scope $Context))
            }
        }

        foreach ($reference in @(Get-MReference $tokens $Scope $Context)) {
            if ($reference -ceq $Name) { continue }
            $referenced = if ($Scope.Steps.ContainsKey($reference)) { Resolve-MStepSource $reference $Scope $Context }
            else { Resolve-MSharedSource $reference $Context }
            foreach ($source in $referenced) { $sources.Add($source) }
        }

        foreach ($fields in @(Get-MNavigationRecord $tokens $Scope $Context)) {
            foreach ($source in $sources) { Set-MNavigation $source $fields }
        }
        foreach ($query in $nativeQueries) {
            foreach ($source in $sources) {
                if (-not $source.NativeQuery -and -not $source.Object) { $source.NativeQuery = $query }
            }
        }

        [void]$Scope.Resolving.Remove($Name)
        $Scope.Cache[$Name] = $sources
    }
    foreach ($source in $Scope.Cache[$Name]) { $result.Add((Copy-MSource $source)) }
    , $result
}

function Resolve-MSharedSource {
    param([string] $Name, $Context)
    $result = [System.Collections.Generic.List[hashtable]]::new()
    if (-not $Context.SharedCache.ContainsKey($Name)) {
        if ($Context.Depth -ge 30 -or -not $Context.Resolving.Add($Name)) { return , $result }
        $Context.Depth++
        try {
            $Context.SharedCache[$Name] = Resolve-MExpressionSource (Get-MSharedToken $Name $Context) $Context
        }
        finally {
            $Context.Depth--
            [void]$Context.Resolving.Remove($Name)
        }
    }
    foreach ($source in $Context.SharedCache[$Name]) { $result.Add((Copy-MSource $source)) }
    , $result
}

function Resolve-MExpressionSource {
    param([System.Collections.Generic.List[object]] $Tokens, $Context)
    $split = Split-MLetExpression $Tokens
    $scope = [pscustomobject]@{
        Steps     = [System.Collections.Generic.Dictionary[string, object]]::new([System.StringComparer]::Ordinal)
        Cache     = [System.Collections.Generic.Dictionary[string, object]]::new([System.StringComparer]::Ordinal)
        Resolving = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::Ordinal)
    }
    foreach ($step in $split.Steps) { $scope.Steps[$step.Name] = $step.Body }

    $final = '__result'
    if ($split.Result.Count -eq 1 -and $split.Result[0].Type -eq 'Identifier' -and $scope.Steps.ContainsKey($split.Result[0].Value)) {
        $final = $split.Result[0].Value
    }
    elseif ($split.Result.Count -gt 0) { $scope.Steps[$final] = $split.Result }
    elseif ($split.Steps.Count -gt 0) { $final = $split.Steps[$split.Steps.Count - 1].Name }
    else { return , [System.Collections.Generic.List[hashtable]]::new() }

    Resolve-MStepSource $final $scope $Context
}

function Get-MSharedContext {
    # Tables in one model share the same expressions dictionary, so the parsed shared queries are cached for
    # as long as the caller keeps passing the same dictionary instance.
    param([System.Collections.IDictionary] $SharedExpression)
    $cache = $script:SharedContextCache
    if ($null -ne $cache -and [object]::ReferenceEquals($cache.Source, $SharedExpression) -and $cache.Count -eq $SharedExpression.Count) {
        return $cache.Context
    }
    $shared = [System.Collections.Generic.Dictionary[string, string]]::new([System.StringComparer]::Ordinal)
    foreach ($key in $SharedExpression.Keys) {
        if ($null -ne $SharedExpression[$key]) { $shared[[string]$key] = [string]$SharedExpression[$key] }
    }
    $context = [pscustomobject]@{
        Shared       = $shared
        SharedTokens = [System.Collections.Generic.Dictionary[string, object]]::new([System.StringComparer]::Ordinal)
        SharedCache  = [System.Collections.Generic.Dictionary[string, object]]::new([System.StringComparer]::Ordinal)
        Resolving    = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::Ordinal)
        Depth        = 0
    }
    $script:SharedContextCache = [pscustomobject]@{ Source = $SharedExpression; Count = $SharedExpression.Count; Context = $context }
    $context
}

function Get-MRefinedSourceType {
    param([string] $SourceType, [string] $Server)
    switch -Regex ($Server) {
        '\.datawarehouse\.fabric\.microsoft\.com|\.datawarehouse\.pbidedicated\.windows\.net' { return 'Fabric SQL analytics endpoint / Warehouse' }
        '\.database\.fabric\.microsoft\.com' { return 'Fabric SQL database' }
        '\.sql\.azuresynapse\.net' { return 'Azure Synapse Analytics' }
        '\.database\.windows\.net' { return 'Azure SQL Database' }
        '^powerbi://' { return 'Power BI semantic model' }
        '^asazure://' { return 'Azure Analysis Services' }
    }
    $SourceType
}

function ConvertTo-MSourceObject {
    # Expands native SQL into one entry per referenced table and returns de-duplicated output objects.
    param([System.Collections.Generic.List[hashtable]] $Sources)
    $seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
    foreach ($source in $Sources) {
        $expanded = if ($source.Object) {
            $source.ObjectOrigin = 'Navigation'
            , $source
        }
        elseif ($source.NativeQuery) {
            $objects = @(Get-SqlReferencedObject -Query $source.NativeQuery)
            if ($objects.Count -eq 0) {
                $source.ObjectOrigin = 'Native query (no tables parsed)'
                , $source
            }
            else {
                foreach ($object in $objects) {
                    $copy = Copy-MSource $source
                    if ($object.Database) { $copy.Database = $object.Database }
                    $copy.Schema = $object.Schema
                    $copy.Object = $object.Object
                    $copy.ObjectKind = 'Referenced in native query'
                    $copy.ObjectOrigin = 'Native query'
                    , $copy
                }
            }
        }
        else {
            $source.ObjectOrigin = 'Connection only'
            , $source
        }

        foreach ($item in $expanded) {
            $key = ($item.Connector, $item.Server, $item.Database, $item.Schema, $item.Object, $item.Location, $item.NativeQuery) -join [char]31
            if (-not $seen.Add($key)) { continue }
            [pscustomobject][ordered]@{
                SourceType   = Get-MRefinedSourceType $item.SourceType $item.Server
                Connector    = $item.Connector
                Server       = $item.Server
                Database     = $item.Database
                Schema       = $item.Schema
                Object       = $item.Object
                ObjectKind   = $item.ObjectKind
                ObjectOrigin = $item.ObjectOrigin
                Location     = $item.Location
                Options      = (@($item.Options.GetEnumerator() | Sort-Object Key | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join '; ')
                NativeQuery  = $item.NativeQuery
            }
        }
    }
}

#endregion

#region Public

function Get-MQuerySource {
    <#
    .SYNOPSIS
        Returns the upstream sources (server, database, schema, object) behind a Power Query (M) expression.
    .PARAMETER Expression
        The M expression of a table partition, refresh policy or shared query.
    .PARAMETER SharedExpression
        The model's shared expressions (named queries and parameters) as name -> M text. References to them
        are followed. Pass the same dictionary instance for every table in a model so parsing is reused.
    .EXAMPLE
        Get-MQuerySource -Expression 'let Source = Sql.Database("sql01", "DW"), T = Source{[Schema="dbo",Item="Sales"]}[Data] in T'
    #>
    [CmdletBinding()]
    [OutputType([pscustomobject])]
    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [AllowEmptyString()]
        [string] $Expression,

        [System.Collections.IDictionary] $SharedExpression = @{}
    )
    process {
        if ([string]::IsNullOrWhiteSpace($Expression)) { return }
        $context = Get-MSharedContext $SharedExpression
        $sources = Resolve-MExpressionSource (Get-MToken $Expression) $context
        ConvertTo-MSourceObject $sources
    }
}

function Get-NativeQuerySource {
    <#
    .SYNOPSIS
        Builds source objects for a SQL query bound to a known connection, e.g. a legacy query partition.
    #>
    [CmdletBinding()]
    [OutputType([pscustomobject])]
    param(
        [Parameter(Mandatory)][string] $Query,
        [string] $SourceType = '',
        [string] $Connector = '',
        [string] $Server = '',
        [string] $Database = ''
    )
    $source = New-MSource -Connector $Connector -SourceType $SourceType
    $source.Server = $Server
    $source.Database = $Database
    $source.NativeQuery = $Query
    $list = [System.Collections.Generic.List[hashtable]]::new()
    $list.Add($source)
    ConvertTo-MSourceObject $list
}

function Get-SqlReferencedObject {
    <#
    .SYNOPSIS
        Lists the tables, views and procedures named after FROM, JOIN and EXEC in a SQL statement.
    .DESCRIPTION
        A pattern match, not a SQL parser. CTE names, temp tables and table variables are excluded. Dynamic
        SQL and objects referenced only inside functions or views are not visible.
    #>
    [CmdletBinding()]
    [OutputType([pscustomobject])]
    param(
        [Parameter(Mandatory, ValueFromPipeline)]
        [AllowEmptyString()]
        [string] $Query
    )
    process {
        $sql = [regex]::Replace($Query, '--[^\r\n]*|/\*.*?\*/', ' ', 'Singleline')
        $sql = [regex]::Replace($sql, "'(?:[^']|'')*'", "''")

        $part = '(?:\[[^\]]+\]|"[^"]+"|`[^`]+`|[\p{L}_@#$][\p{L}\p{Nd}_@#$]*)'
        $qualifiedName = "$part(?:\s*\.\s*$part){0,3}"

        $cteNames = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
        foreach ($m in [regex]::Matches($sql, "(?i)(?:\bwith\s+(?:recursive\s+)?|,\s*)($part)\s*(?:\([^)]*\)\s*)?as\s*\(")) {
            [void]$cteNames.Add($m.Groups[1].Value.Trim('[', ']', '"', '`'))
        }

        $pattern = "(?i)(?<!\b(?:year|month|day|hour|minute|second|epoch|quarter|week|leading|trailing|both)\s+)\b(?:from|join)\s+(?<name>$qualifiedName)|\bexec(?:ute)?\s+(?<name>$qualifiedName)"
        $excluded = @('select', 'lateral', 'unnest', 'values', 'dual', 'openjson', 'openquery', 'openrowset', 'string_split')
        $seen = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)

        foreach ($m in [regex]::Matches($sql, $pattern)) {
            $parts = @([regex]::Matches($m.Groups['name'].Value, $part) | ForEach-Object {
                    $_.Value -replace '^[\["`](.*)[\]"`]$', '$1'
                })
            $object = $parts[-1]
            if ($object -match '^[#@]' -or $excluded -contains $object) { continue }
            if ($parts.Count -eq 1 -and $cteNames.Contains($object)) { continue }
            if (-not $seen.Add(($parts -join '.'))) { continue }
            [pscustomobject][ordered]@{
                Server   = if ($parts.Count -ge 4) { $parts[-4] } else { '' }
                Database = if ($parts.Count -ge 3) { $parts[-3] } else { '' }
                Schema   = if ($parts.Count -ge 2) { $parts[-2] } else { '' }
                Object   = $object
            }
        }
    }
}

#endregion

Export-ModuleMember -Function Get-MQuerySource, Get-NativeQuerySource, Get-SqlReferencedObject
'@

# ==== File 4 of 8: src\modules\RunProgress.psm1 (177 lines) =====================================================
$files['src\modules\RunProgress.psm1'] = @'
#Requires -Version 5.1
<#
.SYNOPSIS
    Compact progress for a run made of numbered steps: one line per step, updated in place, ending with its result.

.DESCRIPTION
    In a console window each step is a single line that shows a live count while it runs and its result when it
    ends:

        [4/8] Listing workspaces ...................... done, 212 workspaces
        [5/8] Scanning workspaces ..................... 100/212 workspaces

    When output is redirected (a log file, a scheduled task, a test), live updates are skipped and each finished
    step is written once to the information stream.
#>

$script:State = $null
$script:LabelWidth = 46

function Format-RunDuration {
    [CmdletBinding()]
    [OutputType([string])]
    param([Parameter(Mandatory)][TimeSpan] $Duration)
    if ($Duration.TotalSeconds -lt 60) { return '{0}s' -f [int][math]::Floor([math]::Max(0, $Duration.TotalSeconds)) }
    if ($Duration.TotalMinutes -lt 60) { return '{0}m {1:00}s' -f [int][math]::Floor($Duration.TotalMinutes), $Duration.Seconds }
    '{0}h {1:00}m' -f [int][math]::Floor($Duration.TotalHours), $Duration.Minutes
}

function Format-RunStepLine {
    [CmdletBinding()]
    [OutputType([string])]
    param(
        [int] $Index,
        [int] $Total,
        [string] $Name,
        [string] $Status,
        [int] $Width = 0
    )
    $label = '  [{0}/{1}] {2} ' -f $Index, $Total, $Name
    if ($label.Length -lt $script:LabelWidth) { $label += '.' * ($script:LabelWidth - $label.Length) }
    $line = if ($Status) { "$label $Status" } else { $label }
    if ($Width -gt 10 -and $line.Length -gt $Width) { $line = $line.Substring(0, $Width - 3) + '...' }
    $line
}

function Get-ConsoleWidth {
    try { [math]::Max(40, [Console]::WindowWidth - 1) } catch { 119 }
}

function Start-RunProgress {
    <#
    .SYNOPSIS
        Begins a run of -TotalSteps steps. Style Auto draws in place in a console window and writes plain lines
        otherwise.
    #>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory)][int] $TotalSteps,
        [ValidateSet('Auto', 'Console', 'Plain')][string] $Style = 'Auto'
    )
    if ($Style -eq 'Auto') {
        $Style = 'Plain'
        if ($Host.Name -eq 'ConsoleHost') {
            try { if (-not [Console]::IsOutputRedirected) { $Style = 'Console' } }
            catch { Write-Verbose 'No console attached; using plain progress lines.' }
        }
    }
    $script:State = [pscustomobject]@{
        Style     = $Style
        Total     = $TotalSteps
        Index     = 0
        Name      = ''
        Open      = $false
        StepTimer = $null
        LastDraw  = [Diagnostics.Stopwatch]::StartNew()
        RunTimer  = [Diagnostics.Stopwatch]::StartNew()
    }
}

function Show-RunStep {
    param([string] $Status, [switch] $Force)
    $state = $script:State
    if ($state.Style -ne 'Console') { return }
    if (-not $Force -and $state.LastDraw.ElapsedMilliseconds -lt 150) { return }
    $width = Get-ConsoleWidth
    $line = Format-RunStepLine $state.Index $state.Total $state.Name $Status $width
    Write-Host ("`r" + $line.PadRight($width)) -NoNewline
    $state.LastDraw.Restart()
}

function Start-RunStep {
    [CmdletBinding()]
    param([Parameter(Mandatory)][string] $Name)
    $state = $script:State
    if ($state.Open) { Complete-RunStep }
    $state.Index++
    $state.Name = $Name
    $state.Open = $true
    $state.StepTimer = [Diagnostics.Stopwatch]::StartNew()
    Show-RunStep -Force
}

function Update-RunStep {
    <#
    .SYNOPSIS
        Shows a live status for the current step, e.g. "37/120 semantic models". Redraws at most every 150 ms
        unless -Force.
    #>
    [CmdletBinding()]
    param([string] $Status, [switch] $Force)
    if ($script:State -and $script:State.Open) { Show-RunStep -Status $Status -Force:$Force }
}

function Complete-RunStep {
    [CmdletBinding()]
    param(
        [string] $Result = 'done',
        [ValidateSet('Success', 'Warning', 'Failure')][string] $Outcome = 'Success'
    )
    $state = $script:State
    if (-not $state -or -not $state.Open) { return }
    $text = $Result
    if ($state.StepTimer.Elapsed.TotalSeconds -ge 2) { $text += " ($(Format-RunDuration $state.StepTimer.Elapsed))" }

    if ($state.Style -eq 'Console') {
        $width = Get-ConsoleWidth
        $label = Format-RunStepLine $state.Index $state.Total $state.Name
        $room = [math]::Max(0, $width - $label.Length - 1)
        if ($text.Length -gt $room) { $text = $text.Substring(0, [math]::Max(0, $room - 3)) + '...' }
        $color = switch ($Outcome) { 'Success' { 'Green' } 'Warning' { 'Yellow' } default { 'Red' } }
        Write-Host ("`r" + $label + ' ') -NoNewline
        Write-Host $text.PadRight($room) -ForegroundColor $color
    }
    else {
        Write-Information (Format-RunStepLine $state.Index $state.Total $state.Name $text) -InformationAction Continue
    }
    $state.Open = $false
}

function Stop-RunStep {
    <#
    .SYNOPSIS
        Marks the current step as failed, so an error message that follows starts on its own line.
    #>
    [CmdletBinding()]
    param()
    if ($script:State -and $script:State.Open) { Complete-RunStep -Result 'failed' -Outcome Failure }
}

function Get-RunElapsed {
    [CmdletBinding()]
    [OutputType([string])]
    param()
    if ($script:State) { Format-RunDuration $script:State.RunTimer.Elapsed } else { '0s' }
}

function Write-RunMessage {
    <#
    .SYNOPSIS
        Writes a summary line in the run's style: to the console with an optional colour, or to the information
        stream.
    #>
    [CmdletBinding()]
    param(
        [string] $Text = '',
        [ValidateSet('', 'Green', 'Yellow', 'Red', 'Cyan', 'Gray')][string] $Color = ''
    )
    if ($script:State -and $script:State.Style -eq 'Console') {
        if ($Color) { Write-Host $Text -ForegroundColor $Color } else { Write-Host $Text }
    }
    else {
        Write-Information $Text -InformationAction Continue
    }
}

Export-ModuleMember -Function Format-RunDuration, Format-RunStepLine, Start-RunProgress, Start-RunStep, Update-RunStep,
    Complete-RunStep, Stop-RunStep, Get-RunElapsed, Write-RunMessage
'@

# ==== File 5 of 8: src\modules\LauncherArguments.psm1 (125 lines) ===============================================
$files['src\modules\LauncherArguments.psm1'] = @'
#Requires -Version 5.1
<#
.SYNOPSIS
    Reads the arguments given to PowerBI-Lineage.cmd into parameters for Get-PbiReportLineage.ps1.

.DESCRIPTION
    The arguments are parsed with the PowerShell parser and only literal values are accepted: text, numbers, lists and
    $true / $false. Nothing in them is executed, so an argument such as "$(Remove-Item ...)" or "; del ..." is
    rejected rather than run.
#>

$script:AllowedParameters = @(
    'Mode', 'WorkspaceId', 'OutputPath', 'ExcelPath', 'SkipExcel', 'TenantId', 'ClientId', 'CertificateThumbprint',
    'ConfigPath', 'IncludePersonalWorkspaces', 'IncludeAutoDateTables', 'SkipGatewayLookup', 'SaveRawResponses',
    'ScanBatchSize', 'Verbose'
)

function Get-LiteralArgumentValue {
    param([System.Management.Automation.Language.Ast] $Ast)
    switch ($Ast.GetType().Name) {
        'StringConstantExpressionAst' { return $Ast.Value }
        'ConstantExpressionAst' { return $Ast.Value }
        'ExpandableStringExpressionAst' {
            if ($Ast.NestedExpressions.Count -gt 0) { throw "Arguments must be plain values; '$($Ast.Extent.Text)' contains an expression." }
            return $Ast.Value
        }
        'ArrayLiteralAst' { return , @($Ast.Elements | ForEach-Object { Get-LiteralArgumentValue $_ }) }
        'VariableExpressionAst' {
            if ($Ast.VariablePath.UserPath -eq 'true') { return $true }
            if ($Ast.VariablePath.UserPath -eq 'false') { return $false }
        }
    }
    throw "Arguments must be plain values; '$($Ast.Extent.Text)' is not."
}

function ConvertFrom-LauncherArgument {
    <#
    .SYNOPSIS
        Converts a command line such as "-Mode Admin -WorkspaceId a,b -SkipExcel" into a parameter hashtable.
    .OUTPUTS
        A hashtable to splat. It holds only the key Help when help was asked for (/?, -?, -h, -Help, --help).
    #>
    [CmdletBinding()]
    [OutputType([hashtable])]
    param([AllowEmptyString()][string] $CommandLine)

    $parameters = @{}
    $trimmed = "$CommandLine".Trim()
    if (-not $trimmed) { return $parameters }
    if ($trimmed -in '/?', '-?', '-h', '/h', '-help', '/help', '--help') { return @{ Help = $true } }

    $tokens = $null
    $errors = $null
    $ast = [System.Management.Automation.Language.Parser]::ParseInput("Invoke-Lineage $trimmed", [ref] $tokens, [ref] $errors)
    if ($errors.Count -gt 0) { throw "Could not read the arguments: $($errors[0].Message)" }

    $statements = @($ast.EndBlock.Statements)
    $pipeline = if ($statements.Count -eq 1) { $statements[0] }
    if (-not ($pipeline -is [System.Management.Automation.Language.PipelineAst]) -or $pipeline.PipelineElements.Count -ne 1 -or
        -not ($pipeline.PipelineElements[0] -is [System.Management.Automation.Language.CommandAst])) {
        throw 'Arguments must be parameter names and values only, for example: -Mode Admin -TenantId <tenant>.'
    }

    $pending = $null
    $elements = $pipeline.PipelineElements[0].CommandElements
    for ($i = 1; $i -lt $elements.Count; $i++) {
        $element = $elements[$i]
        if ($element -is [System.Management.Automation.Language.CommandParameterAst]) {
            $name = $script:AllowedParameters | Where-Object { $_ -eq $element.ParameterName } | Select-Object -First 1
            if (-not $name) {
                if ($element.ParameterName -eq 'ClientSecret') {
                    throw 'Do not put the client secret on the command line, where job logs and process lists can show it. Set the PBI_CLIENT_SECRET environment variable instead, or use -CertificateThumbprint or -ConfigPath.'
                }
                throw "Unknown parameter -$($element.ParameterName). Valid parameters: -$($script:AllowedParameters -join ', -')."
            }
            if ($element.Argument) {
                $parameters[$name] = Get-LiteralArgumentValue $element.Argument
                $pending = $null
            }
            else {
                $parameters[$name] = $true
                $pending = $name
            }
        }
        else {
            if (-not $pending) { throw "Unexpected value '$($element.Extent.Text)'. Put a parameter name such as -ExcelPath before it." }
            $parameters[$pending] = Get-LiteralArgumentValue $element
            $pending = $null
        }
    }
    $parameters
}

function Get-LauncherUsage {
    [CmdletBinding()]
    [OutputType([string])]
    param()
    @'
PowerBI-Lineage.cmd: Power BI report lineage

Double-click, or run with no arguments, to answer questions interactively.
Run with arguments for unattended use (orchestrators, Task Scheduler, SQL Agent): no questions, no pause,
exit code 0 on success and 1 on failure. Unattended runs sign in as a service principal.

  PowerBI-Lineage.cmd -Mode Admin -TenantId <tenant> -ClientId <app-id> -CertificateThumbprint <thumbprint>
                      -ExcelPath "\\share\bi\PowerBI-Lineage.xlsx"

  set PBI_CLIENT_SECRET=<secret from your credential store>
  PowerBI-Lineage.cmd -Mode Admin -TenantId <tenant> -ClientId <app-id> -ExcelPath "D:\Reports\Lineage.xlsx"

Parameters:
  -Mode Admin|User|Auto          Admin: whole tenant. User: workspaces the identity belongs to. Default Auto.
  -TenantId, -ClientId           Service principal. Secret from PBI_CLIENT_SECRET, or use:
  -CertificateThumbprint         Certificate in the CurrentUser or LocalMachine personal store.
  -ConfigPath <file>             config.json with tenantId and servicePrincipal settings.
  -ExcelPath <folder|file>       Folder: writes PowerBI-Lineage_DDMMYYHHMM.xlsx. A .xlsx or .csv file is replaced each run; .csv = CSV only.
  -OutputPath <folder>           Folder for the JSON. Default: the Excel file's folder, or Documents\Power BI Lineage.
  -WorkspaceId <id>,<id>         Only these workspaces.
  -SkipExcel                     JSON and CSV only.
  -IncludePersonalWorkspaces, -IncludeAutoDateTables, -SkipGatewayLookup, -SaveRawResponses,
  -ScanBatchSize <1-100>, -Verbose
#~'@
}

Export-ModuleMember -Function ConvertFrom-LauncherArgument, Get-LauncherUsage
'@

# ==== File 6 of 8: src\Get-PbiReportLineage.ps1 (1154 lines) ====================================================
$files['src\Get-PbiReportLineage.ps1'] = @'
#Requires -Version 5.1

<#
.SYNOPSIS
    End-to-end data lineage for Power BI reports: report > semantic model > table > source server, database,
    schema and table/view > gateway.

    Easiest start: double-click PowerBI-Lineage.cmd in the tool folder and answer the questions.

.DESCRIPTION
    For every report the caller can reach, finds the semantic model (dataset) behind it, the tables in that
    model, and for each table the upstream object that populates it. The upstream object is read from the
    table's Power Query (M) expression; gateway and connection details come from the model's data sources.

    Collection modes:

      Admin  Admin scanner API (WorkspaceInfo). Covers every workspace in the tenant in a few calls.
             Needs Fabric Administrator, or a service principal allowed to use read-only admin APIs, plus the
             tenant settings "Enhance admin APIs responses with detailed metadata" and "Enhance admin APIs
             responses with DAX and mashup expressions". Without those settings reports and models still
             appear, but tables and source objects do not.

      User   Only the workspaces the signed-in identity belongs to. Tables and M expressions are read with the
             DAX INFO functions through executeQueries, which needs write permission on the model (Contributor
             or above on its workspace) and the "Dataset Execute Queries REST API" tenant setting.

      Auto   Default. Uses Admin when the caller is a tenant admin, otherwise User.

    Sign-in, whichever suits the run:

      User account       No sign-in parameters. Reuses the current Power BI session or prompts. A Power BI /
                         Fabric administrator gets every workspace in the tenant (Admin mode).
      Service principal  -TenantId and -ClientId with -ClientSecret or -CertificateThumbprint, or -ConfigPath.
                         For Admin mode the service principal must be allowed to use read-only admin APIs and
                         must not have Power BI admin-consent API permissions on its app registration.

    Output:

      report-lineage.json  Everything collected, untruncated: run details, one lineage row per
                           report x table x source object, the source-object view, and every semantic model
                           with its tables, M expressions and data sources. Written first.
      report-lineage.csv   The lineage rows (the All Lineage sheet) untruncated, named after the workbook and
                           saved next to it.
      report-lineage.xlsx  Built from the JSON by Export-PbiLineageWorkbook.ps1: a Summary sheet, an
                           All Lineage sheet, a Source Objects sheet and one sheet per workspace.

    The script is read-only.

.PARAMETER Mode
    Auto (default), Admin or User.

.PARAMETER WorkspaceId
    Limit the run to these workspace IDs. Reports in them are still traced to models in other workspaces.

.PARAMETER OutputPath
    Folder for the JSON; each run writes a timestamped subfolder. Defaults to the git-ignored output/ folder
    inside the tool folder.

.PARAMETER ExcelPath
    Where to write the Excel workbook: a folder, where each run writes PowerBI-Lineage_DDMMYYHHMM.xlsx (the run's
    local date and time), or a .xlsx file, which is replaced on every run. The CSV is named after the workbook.
    A .csv file instead writes the CSV only, with no workbook (and no need for the ImportExcel module).
    Defaults to report-lineage.xlsx next to the JSON.

.PARAMETER SkipExcel
    Write the JSON and CSV only, e.g. where the ImportExcel module is not installed. Build the workbook later with
    Export-PbiLineageWorkbook.ps1 -JsonPath <json> -ExcelPath <xlsx>.

.PARAMETER TenantId
    Tenant ID or domain. Required for service principal sign-in.

.PARAMETER ClientId
    Application (client) ID of the service principal. Supplying it selects service principal sign-in.

.PARAMETER ClientSecret
    Client secret for the service principal, as a SecureString. If omitted with -ClientId and no
    -CertificateThumbprint, the PBI_CLIENT_SECRET environment variable is used.

.PARAMETER CertificateThumbprint
    Thumbprint of a certificate for the service principal, installed with its private key in the CurrentUser
    or LocalMachine personal store.

.PARAMETER ConfigPath
    Path to config.json (copy config.example.json from the tool folder). Signs in as the service principal it describes,
    using servicePrincipal.certificateThumbprint or servicePrincipal.secretFrom.

.PARAMETER IncludePersonalWorkspaces
    Admin mode: include personal workspaces in the scan. User mode: include your own My workspace.

.PARAMETER IncludeAutoDateTables
    Include the LocalDateTable_* / DateTableTemplate_* tables that Power BI Desktop's auto date/time creates.

.PARAMETER SkipGatewayLookup
    Do not call the gateway APIs to turn gateway and gateway data source IDs into names.

.PARAMETER SaveRawResponses
    Also write the raw scanner results (Admin) or INFO query results (User) to a raw/ subfolder, for
    troubleshooting.

.PARAMETER ScanBatchSize
    Workspaces per admin scan request, 1-100.

.PARAMETER PassThru
    Return the lineage rows to the pipeline as well as writing files.

.PARAMETER Interactive
    Ask how to sign in, which reports to cover and where to save the workbook, instead of taking parameters.
    Used by PowerBI-Lineage.cmd.

.PARAMETER Unattended
    For orchestrators and scheduled jobs: never prompt, and refuse to open a browser sign-in, so a job fails with a
    clear message instead of hanging. Requires service principal sign-in. Unless -OutputPath is given, the JSON
    goes next to -ExcelPath, or to Documents\Power BI Lineage. PowerBI-Lineage.cmd adds this switch whenever it is
    run with arguments.

.EXAMPLE
    ./Get-PbiReportLineage.ps1 -ExcelPath 'C:\Reports\PowerBI-Lineage.xlsx'

    Signs in with your own account (prompting if needed). As a Power BI administrator this covers every
    workspace in the tenant.

.EXAMPLE
    $secret = Read-Host 'Client secret' -AsSecureString
    ./Get-PbiReportLineage.ps1 -Mode Admin -TenantId contoso.onmicrosoft.com `
        -ClientId 00000000-0000-0000-0000-000000000000 -ClientSecret $secret

.EXAMPLE
    ./Get-PbiReportLineage.ps1 -Mode Admin -TenantId <tenant-id> -ClientId <app-id> `
        -CertificateThumbprint 38DA4BED389A014E69A6E6D8AE56761E85F0DFA4 -ExcelPath '\\share\bi\lineage.xlsx'

    Scheduled run as a service principal with a certificate.

.EXAMPLE
    $env:PBI_CLIENT_SECRET = '<secret>'
    ./Get-PbiReportLineage.ps1 -Mode Admin -ConfigPath ../config.json

.EXAMPLE
    ./Get-PbiReportLineage.ps1 -Mode User -WorkspaceId 00000000-0000-0000-0000-000000000000 -SkipExcel -PassThru |
        Where-Object ReportName -eq 'Sales Overview' |
        Format-Table TableName, Server, Database, Schema, SourceObject, GatewayName

.NOTES
    Runs in Windows PowerShell 5.1 and PowerShell 7. Missing modules (MicrosoftPowerBIMgmt.Profile, ImportExcel)
    are installed for the current user on first run; no administrator rights are needed.

    Source objects come from reading M code, not from running it. Tables built from dynamic navigation or
    function results show the connection without an object; the full expression is kept in SourceExpression.
    Reports published as part of an app are skipped in Admin mode because they duplicate the originals.
#>
[CmdletBinding()]
param(
    [ValidateSet('Auto', 'Admin', 'User')]
    [string] $Mode = 'Auto',

    [string[]] $WorkspaceId,

    [string] $OutputPath = ([System.IO.Path]::GetFullPath([System.IO.Path]::Combine($PSScriptRoot, '..', 'output'))),

    [string] $ExcelPath,

    [switch] $SkipExcel,

    [string] $TenantId,

    [string] $ClientId,

    [securestring] $ClientSecret,

    [string] $CertificateThumbprint,

    [string] $ConfigPath,

    [switch] $IncludePersonalWorkspaces,

    [switch] $IncludeAutoDateTables,

    [switch] $SkipGatewayLookup,

    [switch] $SaveRawResponses,

    [ValidateRange(1, 100)]
    [int] $ScanBatchSize = 100,

    [switch] $PassThru,

    [switch] $Interactive,

    [switch] $Unattended
)

$ErrorActionPreference = 'Stop'
# PowerShell's own progress bars (web requests, module installs) are noisy, and slow on 5.1; RunProgress replaces them.
$ProgressPreference = 'SilentlyContinue'
if ($PSVersionTable.PSEdition -eq 'Desktop') {
    # Windows PowerShell 5.1 otherwise serialises some arrays as {"value":[...],"Count":n}.
    Remove-TypeData -TypeName System.Array -ErrorAction SilentlyContinue
}
$modulePath = [System.IO.Path]::GetFullPath([System.IO.Path]::Combine($PSScriptRoot, 'modules'))
Import-Module (Join-Path $modulePath 'Prerequisites.psm1') -Force
Import-Module (Join-Path $modulePath 'PowerBIRest.psm1') -Force
Import-Module (Join-Path $modulePath 'MQueryLineage.psm1') -Force
Import-Module (Join-Path $modulePath 'RunProgress.psm1') -Force

$script:StorageModeNames = @{ 0 = 'Import'; 1 = 'DirectQuery'; 2 = 'Default'; 3 = 'Push'; 4 = 'Dual'; 5 = 'Direct Lake' }
$script:PartitionTypeNames = @{ 1 = 'Query'; 2 = 'Calculated'; 3 = 'None'; 4 = 'M'; 5 = 'Entity'; 6 = 'PolicyRange'; 7 = 'CalculationGroup'; 8 = 'Inferred' }
$script:AutoDateTablePattern = '^(LocalDateTable_|DateTableTemplate_)'
$script:NoMetadataHint = 'No table metadata returned. Admin mode: enable the tenant settings "Enhance admin APIs responses with detailed metadata" and "...with DAX and mashup expressions" (models may need a refresh afterwards). User mode: needs Contributor or above on the model''s workspace.'
$script:GatewayNames = $null
$script:GatewayDatasourceNames = @{}
$script:TableSourceCache = @{}
$script:RawFolder = $null
$script:IsServicePrincipal = $false
$script:SignedInAs = ''
$script:Issues = [System.Collections.Generic.List[object]]::new()
$script:UnnamedGateways = [System.Collections.Generic.HashSet[string]]::new()

#region Helpers

function Add-Issue {
    # Problems that don't stop the run (a model you can't read, a workspace you can't open) are collected here
    # instead of printed. They are counted at the end and saved to the JSON and the Issues sheet.
    param([string] $Area, [string] $Item, [string] $Message)
    $script:Issues.Add([pscustomobject][ordered]@{ Area = $Area; Item = $Item; Message = $Message })
    Write-Verbose "$Area '$Item': $Message"
}

function Get-StatusCode {
    param([System.Management.Automation.ErrorRecord] $ErrorRecord)
    $ErrorRecord.Exception.Data['StatusCode']
}

function Save-Raw {
    param([string] $Name, $Content)
    if (-not $script:RawFolder) { return }
    $Content | ConvertTo-Json -Depth 50 | Set-Content -Path (Join-Path $script:RawFolder $Name) -Encoding utf8
}

function Get-WorkspacePath {
    # 'me' stands for the caller's My workspace, whose endpoints have no groups/{id} prefix.
    param([string] $Id)
    if ($Id -eq 'me') { '' } else { "groups/$Id/" }
}

function Resolve-ConfigSecret {
    param([string] $SecretFrom)
    switch -Regex ($SecretFrom) {
        '^env:(.+)$' {
            $value = [Environment]::GetEnvironmentVariable($Matches[1])
            if (-not $value) { throw "Environment variable '$($Matches[1])' named in the config is not set." }
            return ConvertTo-SecureString $value -AsPlainText -Force
        }
        '^keyvault:([^/]+)/(.+)$' {
            return (Get-AzKeyVaultSecret -VaultName $Matches[1] -Name $Matches[2] -ErrorAction Stop).SecretValue
        }
        default { throw "Unsupported secretFrom '$SecretFrom'. Use env:<NAME> or keyvault:<vault>/<secret>." }
    }
}

function Read-MenuChoice {
    param([string] $Question, [string[]] $Options)
    Write-Host ''
    Write-Host $Question
    for ($i = 0; $i -lt $Options.Count; $i++) { Write-Host ('  [{0}] {1}' -f ($i + 1), $Options[$i]) }
    while ($true) {
        $answer = Read-Host "Choose 1-$($Options.Count) (Enter = 1)"
        if (-not $answer) { return 1 }
        $number = $answer.Trim() -as [int]
        if ($number -ge 1 -and $number -le $Options.Count) { return $number }
        Write-Host "Please type a number from 1 to $($Options.Count)." -ForegroundColor Yellow
    }
}

function Read-RequiredValue {
    param([string] $Prompt)
    while ($true) {
        $value = (Read-Host $Prompt).Trim()
        if ($value) { return $value }
        Write-Host 'A value is required.' -ForegroundColor Yellow
    }
}

function Read-InteractiveOption {
    # Fills the script parameters from questions, for people who double-click the launcher.
    Write-Host ''
    Write-Host 'Power BI report lineage' -ForegroundColor Cyan
    Write-Host 'Traces every report to its semantic model, tables, and the database objects and gateways behind them.'

    $signIn = Read-MenuChoice 'How do you want to sign in?' @(
        'With my own account (a browser sign-in window opens)',
        'As a service principal, with a client secret',
        'As a service principal, with a certificate')
    if ($signIn -gt 1) {
        $script:TenantId = Read-RequiredValue 'Tenant ID (or domain, e.g. contoso.onmicrosoft.com)'
        $script:ClientId = Read-RequiredValue 'Application (client) ID'
        if ($signIn -eq 2) { $script:ClientSecret = Read-Host 'Client secret (hidden)' -AsSecureString }
        else { $script:CertificateThumbprint = Read-RequiredValue 'Certificate thumbprint' }
    }

    $scope = Read-MenuChoice 'Which reports should be included?' @(
        'Every workspace in the tenant (needs Power BI administrator rights)',
        'Only workspaces I am a member of')
    $script:Mode = if ($scope -eq 1) { 'Admin' } else { 'User' }

    $folder = Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'Power BI Lineage'
    $default = Resolve-ExcelPath $folder
    Write-Host ''
    $answer = (Read-Host "Save the Excel file to (Enter = $default)").Trim().Trim('"')
    $script:ExcelPath = if ($answer) { Resolve-ExcelPath $answer } else { $default }
    $script:OutputPath = Split-Path -Parent ([System.IO.Path]::GetFullPath($script:ExcelPath))
    Write-Host ''
}

function Connect-ServicePrincipal {
    param(
        [Parameter(Mandatory)][string] $Tenant,
        [Parameter(Mandatory)][string] $AppId,
        [securestring] $Secret,
        [string] $Thumbprint
    )
    if ($Thumbprint) {
        $null = Connect-PowerBIServiceAccount -ServicePrincipal -ApplicationId $AppId -CertificateThumbprint $Thumbprint -Tenant $Tenant -WarningAction SilentlyContinue
    }
    else {
        $null = Connect-PowerBIServiceAccount -ServicePrincipal -Credential ([pscredential]::new($AppId, $Secret)) -Tenant $Tenant -WarningAction SilentlyContinue
    }
    $script:IsServicePrincipal = $true
    $script:SignedInAs = "Service principal $AppId"
}

function Connect-LineageSession {
    if ($ClientId) {
        if (-not $TenantId) { throw '-TenantId is required with -ClientId.' }
        $secret = $ClientSecret
        if (-not $secret -and -not $CertificateThumbprint) {
            if (-not $env:PBI_CLIENT_SECRET) { throw 'Service principal sign-in needs -ClientSecret, -CertificateThumbprint or the PBI_CLIENT_SECRET environment variable.' }
            $secret = ConvertTo-SecureString $env:PBI_CLIENT_SECRET -AsPlainText -Force
        }
        Connect-ServicePrincipal -Tenant $TenantId -AppId $ClientId -Secret $secret -Thumbprint $CertificateThumbprint
        return
    }

    if ($ConfigPath) {
        $config = Get-Content -Raw -Path $ConfigPath | ConvertFrom-Json
        $principal = $config.servicePrincipal
        $secret = if (-not $principal.certificateThumbprint) { Resolve-ConfigSecret $principal.secretFrom }
        Connect-ServicePrincipal -Tenant $config.tenantId -AppId $principal.appId -Secret $secret -Thumbprint $principal.certificateThumbprint
        return
    }

    try {
        $null = Get-PowerBIAccessToken -ErrorAction Stop
        Write-Verbose 'Reusing the existing Power BI session; run Disconnect-PowerBIServiceAccount first to sign in as someone else.'
        $script:SignedInAs = 'Existing Power BI session'
        return
    }
    catch { Write-Verbose 'No existing Power BI session.' }

    if ($Unattended) {
        throw 'Unattended runs sign in as a service principal: pass -TenantId and -ClientId with -CertificateThumbprint (or set PBI_CLIENT_SECRET), or pass -ConfigPath.'
    }
    Update-RunStep 'complete the sign-in in the window that opens' -Force
    $account = Connect-PowerBIServiceAccount -WarningAction SilentlyContinue
    $script:SignedInAs = if ($account.UserName) { "User $($account.UserName)" } else { 'User account' }
}

function Resolve-CollectionMode {
    if ($Mode -eq 'User') { return 'User' }
    try {
        $null = Invoke-PbiRestMethod -Path 'admin/groups?$top=1'
        return 'Admin'
    }
    catch {
        if ((Get-StatusCode $_) -notin 401, 403) { throw }
        if ($Mode -eq 'Admin') {
            $who = if ($script:IsServicePrincipal) {
                'This service principal cannot use the Power BI admin APIs. Add it to a security group allowed by the tenant setting "Service principals can access read-only admin APIs", and remove any Power BI admin-consent API permissions from its app registration.'
            }
            else { 'This account is not a Power BI / Fabric administrator.' }
            throw "$who To cover only the workspaces this identity is a member of, use -Mode User (or choose that option when asked)."
        }
        Write-Verbose 'Not a Power BI administrator; tracing the workspaces this account is a member of (User mode).'
        return 'User'
    }
}

function New-LineageModel {
    [pscustomobject]@{
        Workspaces    = @{}
        Reports       = [System.Collections.Generic.List[object]]::new()
        Datasets      = @{}
        DatasetErrors = @{}
        DatasetIndex  = @{}
    }
}

function New-ReportEntry {
    param($Report, [string] $WorkspaceId)
    [pscustomobject]@{
        Id                 = $Report.id
        Name               = $Report.name
        ReportType         = if ($Report.reportType) { $Report.reportType } else { 'PowerBIReport' }
        WorkspaceId        = $WorkspaceId
        DatasetId          = [string]$Report.datasetId
        DatasetWorkspaceId = if ($Report.datasetWorkspaceId) { $Report.datasetWorkspaceId } else { $WorkspaceId }
    }
}

#endregion

#region Admin mode: scanner API

function Get-AdminWorkspaceId {
    if ($WorkspaceId) { return @($WorkspaceId) }
    $excludePersonal = (-not $IncludePersonalWorkspaces).ToString().ToLowerInvariant()
    @(Invoke-PbiRestMethod -Path "admin/workspaces/modified?excludePersonalWorkspaces=$excludePersonal&excludeInActiveWorkspaces=true") |
        ForEach-Object { $_ } | ForEach-Object id
}

function Get-AdminLineageModel {
    param([string[]] $Ids)
    $model = New-LineageModel
    if (-not $Ids) { return $model }

    $script:ScanTotal = $Ids.Count
    $script:ScanDone = 0
    $onProgress = { param($status) Update-RunStep ('{0:N0}/{1:N0} workspaces, {2}' -f $script:ScanDone, $script:ScanTotal, $status) }
    $batch = 0
    Invoke-PbiWorkspaceScan -WorkspaceId $Ids -BatchSize $ScanBatchSize -OnProgress $onProgress | ForEach-Object {
        $result = $_
        $batch++
        Save-Raw "scan-$batch.json" $result
        $script:ScanDone = [math]::Min($script:ScanTotal, $batch * $ScanBatchSize)
        Update-RunStep ('{0:N0}/{1:N0} workspaces' -f $script:ScanDone, $script:ScanTotal) -Force

        $instances = @{}
        foreach ($instance in @($result.datasourceInstances) + @($result.misconfiguredDatasourceInstances)) {
            if ($instance) { $instances[$instance.datasourceId] = $instance }
        }

        foreach ($workspace in @($result.workspaces | Where-Object { $_ })) {
            $model.Workspaces[$workspace.id] = [pscustomobject]@{ Id = $workspace.id; Name = $workspace.name; Type = $workspace.type }

            foreach ($report in @($workspace.reports | Where-Object { $_ -and -not $_.appId })) {
                $model.Reports.Add((New-ReportEntry $report $workspace.id))
            }

            foreach ($dataset in @($workspace.datasets | Where-Object { $_ })) {
                $shared = @{}
                foreach ($expression in @($dataset.expressions | Where-Object { $_ })) { $shared[$expression.name] = $expression.expression }

                $tables = foreach ($table in @($dataset.tables | Where-Object { $_ })) {
                    [pscustomobject]@{
                        Name             = $table.name
                        IsHidden         = [bool]$table.isHidden
                        StorageMode      = ''
                        PartitionTypes   = ''
                        Expressions      = @($table.source | Where-Object { $_.expression } | ForEach-Object expression)
                        EntityExpression = $null
                    }
                }

                $usages = @($dataset.datasourceUsages) + @($dataset.misconfiguredDatasourceUsages)
                $datasources = foreach ($usage in $usages) {
                    if ($usage -and $instances.ContainsKey($usage.datasourceInstanceId)) { $instances[$usage.datasourceInstanceId] }
                }

                $model.Datasets[$dataset.id] = [pscustomobject]@{
                    Id                = $dataset.id
                    Name              = $dataset.name
                    WorkspaceId       = $workspace.id
                    StorageMode       = if ($dataset.ContentProviderType) { $dataset.ContentProviderType } else { [string]$dataset.targetStorageMode }
                    Tables            = @($tables)
                    SharedExpressions = $shared
                    Datasources       = @($datasources)
                    MetadataError     = $dataset.schemaRetrievalError
                }
            }
        }
    }
    $model
}

#endregion

#region User mode: workspace APIs + DAX INFO functions

function Invoke-DaxQuery {
    param([string] $DatasetPath, [string] $Query)
    $body = @{ queries = @(@{ query = $Query }); serializerSettings = @{ includeNulls = $true } }
    $response = Invoke-PbiRestMethod -Method Post -Path "$DatasetPath/executeQueries" -Body $body
    $result = $response.results | Select-Object -First 1
    if ($result.error) { throw "DAX query failed: $($result.error | ConvertTo-Json -Depth 6 -Compress)" }
    foreach ($row in @($result.tables[0].rows | Where-Object { $_ })) {
        # Columns come back as "[Name]"; strip the brackets.
        $clean = [ordered]@{}
        foreach ($property in $row.PSObject.Properties) { $clean[($property.Name -replace '^.*\[([^\]]*)\]$', '$1')] = $property.Value }
        [pscustomobject]$clean
    }
}

function Get-UserDatasetDetail {
    param($Dataset, [string] $WorkspaceId)
    $datasetPath = "$(Get-WorkspacePath $WorkspaceId)datasets/$($Dataset.id)"

    $datasources = @()
    try { $datasources = @((Invoke-PbiRestMethod -Path "$datasetPath/datasources").value | Where-Object { $_ }) }
    catch { Add-Issue 'Semantic model' $Dataset.name "Data sources could not be read. $($_.Exception.Message)" }

    $tables = @()
    $shared = @{}
    $metadataError = $null
    try {
        $infoTables = @(Invoke-DaxQuery $datasetPath 'EVALUATE INFO.TABLES()')
        $partitions = @(Invoke-DaxQuery $datasetPath 'EVALUATE INFO.PARTITIONS()')
        $expressions = @(Invoke-DaxQuery $datasetPath 'EVALUATE INFO.EXPRESSIONS()')
        $policies = @()
        if ($partitions | Where-Object { $_.Type -eq 6 }) {
            try { $policies = @(Invoke-DaxQuery $datasetPath 'EVALUATE INFO.REFRESHPOLICIES()') }
            catch { Write-Verbose "[$($Dataset.name)] refresh policies unavailable: $($_.Exception.Message)" }
        }
        Save-Raw "dataset-$($Dataset.id).json" @{ tables = $infoTables; partitions = $partitions; expressions = $expressions; policies = $policies }

        $expressionNameById = @{}
        foreach ($expression in $expressions) {
            $shared[[string]$expression.Name] = [string]$expression.Expression
            $expressionNameById[[string]$expression.ID] = [string]$expression.Name
        }
        $policyByTable = @{}
        foreach ($policy in $policies) { if ($policy.SourceExpression) { $policyByTable[[string]$policy.TableID] = [string]$policy.SourceExpression } }
        $partitionsByTable = @{}
        foreach ($partition in $partitions) {
            $key = [string]$partition.TableID
            if (-not $partitionsByTable.ContainsKey($key)) { $partitionsByTable[$key] = [System.Collections.Generic.List[object]]::new() }
            $partitionsByTable[$key].Add($partition)
        }

        $tables = foreach ($table in $infoTables) {
            $tableKey = [string]$table.ID
            $tablePartitions = if ($partitionsByTable.ContainsKey($tableKey)) { $partitionsByTable[$tableKey] } else { @() }

            $tableExpressions = [System.Collections.Generic.List[string]]::new()
            foreach ($partition in $tablePartitions) {
                if ($partition.QueryDefinition -and -not $tableExpressions.Contains([string]$partition.QueryDefinition)) {
                    $tableExpressions.Add([string]$partition.QueryDefinition)
                }
            }
            if ($policyByTable.ContainsKey($tableKey) -and -not $tableExpressions.Contains($policyByTable[$tableKey])) {
                $tableExpressions.Add($policyByTable[$tableKey])
            }
            $entity = $tablePartitions | Where-Object { $_.Type -eq 5 -and $null -ne $_.ExpressionSourceID } | Select-Object -First 1

            [pscustomobject]@{
                Name             = [string]$table.Name
                IsHidden         = [bool]$table.IsHidden
                StorageMode      = (@($tablePartitions | Where-Object { $null -ne $_.Mode } | ForEach-Object {
                            $name = $script:StorageModeNames[[int]$_.Mode]; if ($name) { $name } else { "Mode $($_.Mode)" }
                        } | Sort-Object -Unique) -join ', ')
                PartitionTypes   = (@($tablePartitions | Where-Object { $null -ne $_.Type } | ForEach-Object {
                            $name = $script:PartitionTypeNames[[int]$_.Type]; if ($name) { $name } else { "Type $($_.Type)" }
                        } | Sort-Object -Unique) -join ', ')
                Expressions      = @($tableExpressions)
                EntityExpression = if ($entity) { $expressionNameById[[string]$entity.ExpressionSourceID] }
            }
        }
    }
    catch {
        $metadataError = $_.Exception.Message
        Add-Issue 'Semantic model' $Dataset.name "Tables could not be read (needs Contributor or above on its workspace). $metadataError"
    }

    [pscustomobject]@{
        Id                = $Dataset.id
        Name              = $Dataset.name
        WorkspaceId       = $WorkspaceId
        StorageMode       = [string]$Dataset.targetStorageMode
        Tables            = @($tables)
        SharedExpressions = $shared
        Datasources       = @($datasources)
        MetadataError     = $metadataError
    }
}

function Get-UserWorkspaceTarget {
    # Lists the workspaces this identity belongs to, records their names on the model, and returns the IDs to read.
    param($Model)
    $allGroups = @(Get-PbiPagedValue -Path 'groups')
    foreach ($group in $allGroups) {
        $Model.Workspaces[$group.id] = [pscustomobject]@{ Id = $group.id; Name = $group.name; Type = $group.type }
    }
    $Model.Workspaces['me'] = [pscustomobject]@{ Id = 'me'; Name = 'My workspace'; Type = 'PersonalGroup' }

    $targets = @(@(if ($WorkspaceId) { $allGroups | Where-Object { $_.id -in $WorkspaceId } } else { $allGroups }) | ForEach-Object id)
    if ($WorkspaceId) {
        foreach ($missing in $WorkspaceId | Where-Object { $_ -notin $targets }) {
            Add-Issue 'Workspace' $missing 'Not visible to this account, so it was skipped.'
        }
    }
    if ($IncludePersonalWorkspaces -and $script:IsServicePrincipal) {
        Add-Issue 'Workspace' 'My workspace' 'A service principal has no My workspace; -IncludePersonalWorkspaces was ignored.'
    }
    elseif ($IncludePersonalWorkspaces) { $targets = @('me') + $targets }
    , $targets
}

function Read-UserReport {
    param($Model, [string[]] $Targets)
    $i = 0
    foreach ($id in $Targets) {
        $i++
        Update-RunStep ('{0:N0}/{1:N0} workspaces, {2:N0} reports so far' -f $i, $Targets.Count, $Model.Reports.Count)
        $prefix = Get-WorkspacePath $id
        try {
            $reports = @((Invoke-PbiRestMethod -Path "${prefix}reports").value | Where-Object { $_ })
            foreach ($report in $reports) { $Model.Reports.Add((New-ReportEntry $report $id)) }
            if ($reports.Count -gt 0) {
                foreach ($dataset in @((Invoke-PbiRestMethod -Path "${prefix}datasets").value | Where-Object { $_ })) {
                    $Model.DatasetIndex[$dataset.id] = $dataset
                }
            }
        }
        catch { Add-Issue 'Workspace' $Model.Workspaces[$id].Name "Skipped: reports could not be listed. $($_.Exception.Message)" }
    }
}

function Read-UserDataset {
    param($Model)
    $referenced = @($Model.Reports | Where-Object DatasetId | Group-Object DatasetId)
    $i = 0
    foreach ($group in $referenced) {
        $i++
        Update-RunStep ('{0:N0}/{1:N0} semantic models' -f $i, $referenced.Count)
        $datasetId = $group.Name
        $datasetWorkspaceId = $group.Group[0].DatasetWorkspaceId
        $dataset = $Model.DatasetIndex[$datasetId]
        if (-not $dataset) {
            try { $dataset = Invoke-PbiRestMethod -Path "$(Get-WorkspacePath $datasetWorkspaceId)datasets/$datasetId" }
            catch {
                $message = "Semantic model not accessible to this account. $($_.Exception.Message)"
                $Model.DatasetErrors[$datasetId] = $message
                Add-Issue 'Semantic model' $datasetId $message
                continue
            }
        }
        $Model.Datasets[$datasetId] = Get-UserDatasetDetail $dataset $datasetWorkspaceId
    }
}

#endregion

#region Lineage rows

function Format-Endpoint {
    param([string] $Value)
    if (-not $Value) { return '' }
    $Value.Trim().ToLowerInvariant() -replace '^tcp:', '' -replace ',\d+$', '' -replace '/+$', ''
}

function Test-Unresolved {
    param([string] $Value)
    [string]::IsNullOrEmpty($Value) -or $Value -match '\{[^}]+\}'
}

function Find-BoundDatasource {
    # Matches a parsed source to one of the model's bound data sources, which carry the gateway binding.
    param($Source, $Datasources)
    $candidates = @($Datasources | Where-Object { $_ })
    if ($candidates.Count -eq 0) { return }

    $server = if (Test-Unresolved $Source.Server) { '' } else { Format-Endpoint $Source.Server }
    $location = if (Test-Unresolved $Source.Location) { '' } else { Format-Endpoint $Source.Location }
    $best = $null
    $bestScore = 0
    foreach ($datasource in $candidates) {
        $details = $datasource.connectionDetails
        $score = 0
        if ($server -and (Format-Endpoint $details.server) -eq $server) {
            $score = 2
            if ($Source.Database -and $details.database) { $score = if ($Source.Database -eq $details.database) { 3 } else { 0 } }
        }
        elseif ($location) {
            foreach ($endpoint in @($details.url, $details.path) | ForEach-Object { Format-Endpoint $_ } | Where-Object { $_ }) {
                if ($location.StartsWith($endpoint) -or $endpoint.StartsWith($location)) { $score = 2 }
            }
        }
        if ($score -gt $bestScore) { $best = $datasource; $bestScore = $score }
    }
    if (-not $best -and -not $server -and -not $location -and $candidates.Count -eq 1) { $best = $candidates[0] }
    $best
}

function Get-GatewayName {
    param([string] $GatewayId)
    if (-not $GatewayId -or $SkipGatewayLookup) { return '' }
    if ($null -eq $script:GatewayNames) {
        $script:GatewayNames = @{}
        try {
            foreach ($gateway in @((Invoke-PbiRestMethod -Path 'gateways').value | Where-Object { $_ })) {
                $script:GatewayNames[$gateway.id] = $gateway.name
            }
        }
        catch { Write-Verbose "Gateway list unavailable: $($_.Exception.Message)" }
    }
    $name = [string]$script:GatewayNames[$GatewayId]
    if (-not $name) { [void]$script:UnnamedGateways.Add($GatewayId) }
    $name
}

function Get-GatewayDatasourceName {
    param([string] $GatewayId, [string] $DatasourceId)
    if (-not $GatewayId -or -not $DatasourceId -or $SkipGatewayLookup) { return '' }
    $key = "$GatewayId/$DatasourceId"
    if (-not $script:GatewayDatasourceNames.ContainsKey($key)) {
        $script:GatewayDatasourceNames[$key] = try {
            [string](Invoke-PbiRestMethod -Path "gateways/$GatewayId/datasources/$DatasourceId").datasourceName
        }
        catch { Write-Verbose "Gateway data source $key unavailable: $($_.Exception.Message)"; '' }
    }
    $script:GatewayDatasourceNames[$key]
}

function Get-TableSource {
    param($Dataset, $Table)
    $key = "$($Dataset.Id)|$($Table.Name)"
    if ($script:TableSourceCache.ContainsKey($key)) { return $script:TableSourceCache[$key] }

    $sources = [System.Collections.Generic.List[object]]::new()
    foreach ($expression in $Table.Expressions) {
        if ($expression -match '^\s*(?:select|with)\s') {
            # Legacy query partition: plain SQL bound to the model's (single) data source.
            $datasource = if (@($Dataset.Datasources).Count -eq 1) { $Dataset.Datasources[0] }
            $parameters = @{
                Query      = $expression
                Connector  = 'Query partition'
                SourceType = [string]$datasource.datasourceType
                Server     = [string]$datasource.connectionDetails.server
                Database   = [string]$datasource.connectionDetails.database
            }
            foreach ($source in Get-NativeQuerySource @parameters) { $sources.Add($source) }
        }
        else {
            foreach ($source in Get-MQuerySource -Expression $expression -SharedExpression $Dataset.SharedExpressions) { $sources.Add($source) }
        }
    }

    if ($sources.Count -eq 0 -and $Table.EntityExpression) {
        # Direct Lake / entity partition: the connection is a shared expression; the entity is assumed to share the table's name.
        $reference = '#"' + $Table.EntityExpression.Replace('"', '""') + '"'
        foreach ($source in Get-MQuerySource -Expression $reference -SharedExpression $Dataset.SharedExpressions) {
            if (-not $source.Object) {
                $source.Object = $Table.Name
                $source.ObjectOrigin = 'Direct Lake entity (name assumed from table)'
            }
            $sources.Add($source)
        }
    }

    $script:TableSourceCache[$key] = $sources
    $sources
}

function Select-Value {
    param([string] $Preferred, [string] $Fallback)
    if (Test-Unresolved $Preferred) {
        if ($Fallback) { return $Fallback }
        return [string]$Preferred
    }
    $Preferred
}

function New-LineageRow {
    param(
        [System.Collections.IDictionary] $Base,
        $Table,
        $Source,
        $Datasource,
        [string] $Notes = ''
    )
    $details = $Datasource.connectionDetails
    $gatewayId = [string]$Datasource.gatewayId
    if ($gatewayId -eq [guid]::Empty.ToString()) { $gatewayId = '' }
    $datasourceId = [string]$Datasource.datasourceId

    $expression = if ($Table) { $Table.Expressions -join "`n----`n" } else { '' }

    $row = [ordered]@{}
    foreach ($key in $Base.Keys) { $row[$key] = $Base[$key] }
    $row.TableName = [string]$Table.Name
    $row.TableIsHidden = if ($Table) { [bool]$Table.IsHidden } else { $null }
    $row.TableStorageMode = [string]$Table.StorageMode
    $row.SourceType = if ($Source.SourceType) { $Source.SourceType } else { [string]$Datasource.datasourceType }
    $row.Connector = [string]$Source.Connector
    $row.Server = Select-Value $Source.Server $details.server
    $row.Database = Select-Value $Source.Database $details.database
    $row.Schema = [string]$Source.Schema
    $row.SourceObject = [string]$Source.Object
    $row.SourceObjectKind = [string]$Source.ObjectKind
    $row.ObjectOrigin = [string]$Source.ObjectOrigin
    $row.Location = Select-Value $Source.Location $(if ($details.url) { $details.url } else { $details.path })
    $row.ConnectorOptions = [string]$Source.Options
    $row.NativeQuery = [string]$Source.NativeQuery
    $row.DatasourceType = [string]$Datasource.datasourceType
    $row.GatewayId = $gatewayId
    $row.GatewayName = Get-GatewayName $gatewayId
    $row.GatewayDatasourceId = if ($gatewayId) { $datasourceId } else { '' }
    $row.GatewayDatasourceName = Get-GatewayDatasourceName $gatewayId $datasourceId
    $row.ConnectionDetails = if ($details) { $details | ConvertTo-Json -Compress -Depth 4 } else { '' }
    # Y when anything about the connection mentions Snowflake, including ODBC connections to it.
    $isSnowflake = @($row.SourceType, $row.Connector, $row.Server, $row.DatasourceType, $row.ConnectionDetails) -match 'snowflake'
    $row.IsSnowflakeConnection = if ($isSnowflake) { 'Y' } else { 'N' }
    $row.Notes = $Notes
    $row.SourceExpression = $expression
    [pscustomobject]$row
}

function Get-SourceNote {
    param($Source, $Datasource)
    $notes = [System.Collections.Generic.List[string]]::new()
    if ($Source.ObjectOrigin -eq 'Connection only') {
        $notes.Add('Source object not identified from the M code (whole database/file/feed, or dynamic navigation); see SourceExpression.')
    }
    if ($Source.ObjectOrigin -like 'Native query*') {
        $notes.Add('Object read from native SQL; views or procedures may hide further tables.')
    }
    if ((Test-Unresolved $Source.Server) -and $Source.Server -and -not $Datasource) {
        $notes.Add('Server comes from a parameter that could not be resolved statically.')
    }
    $notes -join ' '
}

function Get-TableNote {
    param($Table)
    if ($Table.PartitionTypes -match 'CalculationGroup') { return 'Calculation group; no external source.' }
    if ($Table.PartitionTypes -match 'Calculated') { return 'Calculated table (DAX); built from other model tables.' }
    if (@($Table.Expressions).Count -eq 0) { return 'No source expression returned for this table.' }
    'No external source recognised in the expression (DAX calculated table, #table literal or unsupported connector); see SourceExpression.'
}

function Get-LineageRow {
    param($Model)
    $index = 0
    foreach ($report in $Model.Reports) {
        $index++
        Update-RunStep ('{0:N0}/{1:N0} reports' -f $index, $Model.Reports.Count)
        $base = [ordered]@{
            WorkspaceName        = [string]$Model.Workspaces[$report.WorkspaceId].Name
            WorkspaceId          = $report.WorkspaceId
            ReportName           = $report.Name
            ReportId             = $report.Id
            ReportType           = $report.ReportType
            DatasetName          = ''
            DatasetId            = $report.DatasetId
            DatasetWorkspaceName = ''
            DatasetWorkspaceId   = $report.DatasetWorkspaceId
            DatasetStorageMode   = ''
        }

        if (-not $report.DatasetId) {
            $note = if ($report.ReportType -eq 'PaginatedReport') { 'Paginated report: queries are embedded in the RDL, so lineage stops at the connection.' }
            else { 'Report is not bound to a semantic model.' }
            $datasources = @()
            try {
                $datasources = @((Invoke-PbiRestMethod -Path "$(Get-WorkspacePath $report.WorkspaceId)reports/$($report.Id)/datasources").value | Where-Object { $_ })
            }
            catch {
                $note += " Data sources unavailable: $($_.Exception.Message)"
                Add-Issue 'Report' $report.Name "Data sources of this paginated report could not be read. $($_.Exception.Message)"
            }
            if ($datasources.Count -eq 0) { New-LineageRow $base -Notes $note }
            foreach ($datasource in $datasources) { New-LineageRow $base -Datasource $datasource -Notes $note }
            continue
        }

        $dataset = $Model.Datasets[$report.DatasetId]
        if (-not $dataset) {
            $note = $Model.DatasetErrors[$report.DatasetId]
            if (-not $note) { $note = 'Semantic model is outside the scanned workspaces or not accessible.' }
            New-LineageRow $base -Notes $note
            continue
        }

        $base.DatasetName = $dataset.Name
        $base.DatasetWorkspaceId = $dataset.WorkspaceId
        $base.DatasetWorkspaceName = [string]$Model.Workspaces[$dataset.WorkspaceId].Name
        $base.DatasetStorageMode = $dataset.StorageMode

        $tables = @($dataset.Tables | Where-Object { $_ -and ($IncludeAutoDateTables -or $_.Name -notmatch $script:AutoDateTablePattern) })
        if ($tables.Count -eq 0) {
            $note = if ($dataset.MetadataError) { "No table metadata: $($dataset.MetadataError)" } else { $script:NoMetadataHint }
            if (@($dataset.Datasources).Count -eq 0) { New-LineageRow $base -Notes $note }
            foreach ($datasource in $dataset.Datasources) { New-LineageRow $base -Datasource $datasource -Notes $note }
            continue
        }

        foreach ($table in $tables) {
            $sources = Get-TableSource $dataset $table
            if ($sources.Count -eq 0) {
                New-LineageRow $base -Table $table -Notes (Get-TableNote $table)
                continue
            }
            foreach ($source in $sources) {
                $datasource = Find-BoundDatasource $source $dataset.Datasources
                New-LineageRow $base -Table $table -Source $source -Datasource $datasource -Notes (Get-SourceNote $source $datasource)
            }
        }
    }
}

#endregion

#region Output

function Get-SourceObjectSummary {
    param([object[]] $Rows)
    $Rows | Where-Object { $_.SourceObject -or $_.Server -or $_.Location } |
        Group-Object SourceType, Server, Database, Schema, SourceObject, Location |
        ForEach-Object {
            $group = $_.Group
            $first = $group[0]
            [pscustomobject][ordered]@{
                SourceType   = $first.SourceType
                Server       = $first.Server
                Database     = $first.Database
                Schema       = $first.Schema
                SourceObject = $first.SourceObject
                Location     = $first.Location
                Gateways     = (@($group.GatewayName | Where-Object { $_ } | Sort-Object -Unique) -join '; ')
                ReportCount  = @($group.ReportId | Sort-Object -Unique).Count
                ModelCount   = @($group.DatasetId | Where-Object { $_ } | Sort-Object -Unique).Count
                Reports      = (@($group | ForEach-Object { "$($_.WorkspaceName) / $($_.ReportName)" } | Sort-Object -Unique) -join '; ')
                ModelTables  = (@($group | Where-Object TableName | ForEach-Object { "$($_.DatasetName)[$($_.TableName)]" } | Sort-Object -Unique) -join '; ')
            }
        } |
        Sort-Object SourceType, Server, Database, Schema, SourceObject
}

function New-LineageDocument {
    # The complete, untruncated record of a run. The Excel workbook is built from this document alone.
    param([object[]] $Rows, $Model, [string] $CollectionMode)
    $traced = @($Rows | Where-Object SourceObject).Count
    $connectionOnly = @($Rows | Where-Object { -not $_.SourceObject -and ($_.Server -or $_.Location) }).Count

    [ordered]@{
        schemaVersion  = 1
        generatedAtUtc = (Get-Date).ToUniversalTime().ToString('yyyy-MM-ddTHH:mm:ssZ')
        collectionMode = $CollectionMode
        signedInAs     = $script:SignedInAs
        workspaceScope = if ($WorkspaceId) { @($WorkspaceId) } else { 'All accessible workspaces' }
        summary        = [ordered]@{
            workspaces          = @($Rows.WorkspaceId | Sort-Object -Unique).Count
            reports             = @($Rows.ReportId | Sort-Object -Unique).Count
            semanticModels      = $Model.Datasets.Count
            tables              = [int](@($Model.Datasets.Values | ForEach-Object { @($_.Tables).Count }) | Measure-Object -Sum).Sum
            lineageRows         = $Rows.Count
            tracedToObject      = $traced
            connectionOnly      = $connectionOnly
            noExternalSource    = $Rows.Count - $traced - $connectionOnly
            issues              = $script:Issues.Count
        }
        issues         = @($script:Issues)
        workspaces     = @($Model.Workspaces.Values | Sort-Object Name | ForEach-Object {
                [ordered]@{ id = $_.Id; name = $_.Name; type = $_.Type }
            })
        lineage        = $Rows
        sourceObjects  = @(Get-SourceObjectSummary $Rows)
        semanticModels = @($Model.Datasets.Values | Sort-Object Name | ForEach-Object {
                [ordered]@{
                    id                = $_.Id
                    name              = $_.Name
                    workspaceId       = $_.WorkspaceId
                    workspaceName     = [string]$Model.Workspaces[$_.WorkspaceId].Name
                    storageMode       = $_.StorageMode
                    metadataError     = $_.MetadataError
                    sharedExpressions = $_.SharedExpressions
                    datasources       = @($_.Datasources)
                    tables            = @($_.Tables | ForEach-Object {
                            [ordered]@{
                                name           = $_.Name
                                isHidden       = $_.IsHidden
                                storageMode    = $_.StorageMode
                                partitionTypes = $_.PartitionTypes
                                expressions    = @($_.Expressions)
                            }
                        })
                }
            })
    }
}

#endregion

function Format-Count {
    param([int] $Count, [string] $Singular, [string] $Plural = "${Singular}s")
    '{0:N0} {1}' -f $Count, $(if ($Count -eq 1) { $Singular } else { $Plural })
}

function Resolve-ExcelPath {
    # A folder gets a workbook named after the run's local date and time; a .xlsx or .csv path is used as given.
    param([string] $Path)
    $Path = $Path.Trim().Trim('"')
    if ($Path -match '\.(xlsx|csv)$') { return $Path }
    if ((Split-Path -Leaf $Path) -match '\.[A-Za-z]{2,5}$') { throw "ExcelPath must be a folder, a .xlsx file or a .csv file: $Path" }
    Join-Path $Path ('PowerBI-Lineage_{0:ddMMyyHHmm}.xlsx' -f (Get-Date))
}

if ($Interactive -and $Unattended) { throw '-Interactive and -Unattended cannot be used together.' }
if ($ExcelPath) { $ExcelPath = Resolve-ExcelPath $ExcelPath }
if ($Unattended -and -not $PSBoundParameters.ContainsKey('OutputPath')) {
    # The default output folder sits inside the script's own folder, which PowerBI-Lineage.cmd replaces on update.
    $OutputPath = if ($ExcelPath) {
        Split-Path -Parent $ExecutionContext.SessionState.Path.GetUnresolvedProviderPathFromPSPath($ExcelPath)
    }
    else {
        $documents = [Environment]::GetFolderPath('MyDocuments')
        if ($documents) { Join-Path $documents 'Power BI Lineage' } else { Join-Path (Get-Location).Path 'Power BI Lineage' }
    }
}

if ($Interactive) { Read-InteractiveOption }
# A .csv path asks for the CSV only.
if ($ExcelPath -match '\.csv$') { $SkipExcel = [switch]$true }
else { Write-RunMessage ''; Write-RunMessage 'Power BI report lineage' -Color Cyan }

Start-RunProgress -TotalSteps 8
try {
    Start-RunStep 'Checking prerequisites'
    $required = @('MicrosoftPowerBIMgmt.Profile')
    if (-not $SkipExcel) { $required += 'ImportExcel' }
    foreach ($name in $required) {
        if (-not (Find-RequiredModule -Name $name)) { Update-RunStep "installing $name (first run only)" -Force }
        Initialize-RequiredModule -Name $name
    }
    Complete-RunStep

    Start-RunStep 'Signing in'
    Connect-LineageSession
    Complete-RunStep "done, $($script:SignedInAs)"

    Start-RunStep 'Checking access'
    $effectiveMode = Resolve-CollectionMode
    Complete-RunStep $(if ($effectiveMode -eq 'Admin') { 'done, whole tenant (administrator)' } else { 'done, workspaces this account is a member of' })

    $runFolder = Join-Path $OutputPath ('report-lineage-{0:yyyyMMdd-HHmmss}' -f (Get-Date))
    $null = New-Item -ItemType Directory -Path $runFolder -Force
    if ($SaveRawResponses) {
        $script:RawFolder = Join-Path $runFolder 'raw'
        $null = New-Item -ItemType Directory -Path $script:RawFolder -Force
    }

    Start-RunStep 'Listing workspaces'
    if ($effectiveMode -eq 'Admin') {
        $model = New-LineageModel
        $workspaceIds = @(Get-AdminWorkspaceId)
        if ($workspaceIds.Count -eq 0) { Add-Issue 'Workspace' '' 'No workspaces were found to scan.' }
    }
    else {
        $model = New-LineageModel
        $workspaceIds = Get-UserWorkspaceTarget $model
    }
    Complete-RunStep "done, $(Format-Count $workspaceIds.Count 'workspace')"

    if ($effectiveMode -eq 'Admin') {
        Start-RunStep 'Scanning workspaces'
        $model = Get-AdminLineageModel -Ids $workspaceIds
        Complete-RunStep "done, $(Format-Count $model.Reports.Count 'report'), $(Format-Count $model.Datasets.Count 'semantic model')"

        Start-RunStep 'Reading tables and data sources'
        $withoutTables = @($model.Datasets.Values | Where-Object { @($_.Tables).Count -eq 0 })
        foreach ($dataset in $withoutTables | Where-Object MetadataError) {
            Add-Issue 'Semantic model' $dataset.Name "Tables could not be read. $($dataset.MetadataError)"
        }
        $silent = @($withoutTables | Where-Object { -not $_.MetadataError }).Count
        if ($silent -gt 0 -and $silent -eq $model.Datasets.Count) {
            Add-Issue 'Tenant settings' '' "No tables were returned for any of the $silent semantic models. A Power BI admin needs to enable 'Enhance admin APIs responses with detailed metadata' and 'Enhance admin APIs responses with DAX and mashup expressions'."
        }
        $tableCount = @($model.Datasets.Values | ForEach-Object { @($_.Tables).Count } | Measure-Object -Sum).Sum
        Complete-RunStep "done, $(Format-Count $tableCount 'table') (from the scan)"
    }
    else {
        Start-RunStep 'Reading reports'
        Read-UserReport $model $workspaceIds
        Complete-RunStep "done, $(Format-Count $model.Reports.Count 'report')"

        Start-RunStep 'Reading tables and data sources'
        Read-UserDataset $model
        $tableCount = @($model.Datasets.Values | ForEach-Object { @($_.Tables).Count } | Measure-Object -Sum).Sum
        Complete-RunStep "done, $(Format-Count $model.Datasets.Count 'semantic model'), $(Format-Count $tableCount 'table')"
    }

    Start-RunStep 'Tracing lineage'
    $rows = @(Get-LineageRow -Model $model)
    if ($script:UnnamedGateways.Count -gt 0) {
        Add-Issue 'Gateway' '' "Names not available for $(Format-Count $script:UnnamedGateways.Count 'gateway'); their IDs are listed. Names need admin rights on the gateway."
    }
    $traced = @($rows | Where-Object SourceObject).Count
    Complete-RunStep "done, $(Format-Count $rows.Count 'row'), $('{0:N0}' -f $traced) traced to a source table"

    Start-RunStep 'Saving results'
    $document = New-LineageDocument $rows $model $effectiveMode
    $jsonPath = Join-Path $runFolder 'report-lineage.json'
    ConvertTo-Json -InputObject $document -Depth 20 | Set-Content -Path $jsonPath -Encoding utf8

    # The All Lineage rows as CSV, untruncated, named after the workbook and saved next to it.
    $csvPath = [System.IO.Path]::ChangeExtension($(if ($ExcelPath) { $ExcelPath } else { Join-Path $runFolder 'report-lineage.xlsx' }), '.csv')
    $csvFolder = Split-Path -Parent ([System.IO.Path]::GetFullPath($csvPath))
    if (-not (Test-Path -LiteralPath $csvFolder)) { $null = New-Item -ItemType Directory -Path $csvFolder -Force }
    # UTF-8 with a byte order mark, so Excel opens names with accents correctly.
    $csvEncoding = if ($PSVersionTable.PSVersion.Major -ge 6) { 'utf8BOM' } else { 'UTF8' }
    $csvRows = if ($rows.Count -gt 0) { $rows } else { [pscustomobject]@{} }
    $csvRows | Export-Csv -LiteralPath $csvPath -NoTypeInformation -Encoding $csvEncoding

    if (-not $SkipExcel) {
        Update-RunStep 'building the Excel workbook' -Force
        if (-not $ExcelPath) { $ExcelPath = Join-Path $runFolder 'report-lineage.xlsx' }
        $workbook = & (Join-Path $PSScriptRoot 'Export-PbiLineageWorkbook.ps1') -JsonPath $jsonPath -ExcelPath $ExcelPath -Force
    }
    Complete-RunStep $(if ($SkipExcel) { 'done, JSON and CSV' } else { 'done, JSON, CSV and Excel' })
}
catch {
    Stop-RunStep
    throw
}

$summary = $document.summary
Write-RunMessage ''
Write-RunMessage "Done in $(Get-RunElapsed)." -Color Green
Write-RunMessage ('  {0} | {1} | {2}' -f (Format-Count $summary.reports 'report'), (Format-Count $summary.semanticModels 'semantic model'), (Format-Count $summary.tables 'table'))
Write-RunMessage ('  {0}: {1:N0} traced to a source table, {2:N0} to a connection only, {3:N0} with no external source' -f (Format-Count $summary.lineageRows 'lineage row'), $summary.tracedToObject, $summary.connectionOnly, $summary.noExternalSource)
if ($script:Issues.Count -gt 0) {
    $where = if ($SkipExcel) { 'the "issues" section of the JSON' } else { 'the Issues sheet' }
    $noun = if ($script:Issues.Count -eq 1) { 'issue needs' } else { 'issues need' }
    Write-RunMessage ('  {0:N0} {1} attention; see {2}.' -f $script:Issues.Count, $noun, $where) -Color Yellow
}
if ($workbook) {
    Write-RunMessage ''
    Write-RunMessage '  Workbook sheets:'
    $nameWidth = ($workbook.Sheets.Name | Measure-Object -Property Length -Maximum).Maximum + 3
    foreach ($sheet in $workbook.Sheets) {
        Write-RunMessage ('    {0}{1}' -f $sheet.Name.PadRight($nameWidth), $sheet.Description)
    }
    $workspaceSheetCount = @($workbook.WorkspaceSheets).Count
    if ($workspaceSheetCount -gt 0) { Write-RunMessage "    + $(Format-Count $workspaceSheetCount 'workspace sheet')" }
    Write-RunMessage ''
}
if (-not $SkipExcel) { Write-RunMessage "  Excel: $ExcelPath" }
Write-RunMessage "  CSV:   $csvPath"
Write-RunMessage "  JSON:  $jsonPath"
Write-RunMessage ''

if ($Interactive -and -not $SkipExcel) {
    $open = Read-Host 'Open the workbook now? [Y/n]'
    if ($open -notmatch '^\s*n') { Invoke-Item -LiteralPath $ExcelPath }
}

if ($PassThru) { $rows }
'@

# ==== File 7 of 8: src\Export-PbiLineageWorkbook.ps1 (305 lines) ================================================
$files['src\Export-PbiLineageWorkbook.ps1'] = @'
#Requires -Version 5.1

<#
.SYNOPSIS
    Builds the Excel lineage workbook from the JSON written by Get-PbiReportLineage.ps1.

.DESCRIPTION
    Sheets:

      Summary         Run details, totals, and a list of workspaces linking to their sheets.
      All Lineage     Every lineage row: report > semantic model > table > source object > gateway.
      Source Objects  Each source object with the gateways, reports and model tables that depend on it.
      Issues          Anything that could not be read during the run (a model, a workspace, gateway names).

    Returns an object with the workbook path, the standard sheets and their descriptions, and the workspace sheet names.
      <workspace>     One sheet per workspace, holding the lineage rows of the reports in that workspace.

    Excel holds at most 32,767 characters per cell. Longer values (typically M expressions or native SQL) are
    cut in the workbook and marked; the JSON keeps the full text, so rebuilding from it never loses data.

    Values are written as text, so an M expression starting with '=' does not become a formula and an ID such
    as 0012 keeps its leading zeros.

.PARAMETER JsonPath
    report-lineage.json from a Get-PbiReportLineage.ps1 run.

.PARAMETER ExcelPath
    Path of the .xlsx to create.

.PARAMETER Force
    Replace the workbook if it already exists.

.EXAMPLE
    ./Export-PbiLineageWorkbook.ps1 -JsonPath ../output/report-lineage-20260916-090000/report-lineage.json `
        -ExcelPath 'C:\Reports\PowerBI-Lineage.xlsx' -Force
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string] $JsonPath,

    [Parameter(Mandatory)]
    [string] $ExcelPath,

    [switch] $Force
)

$ErrorActionPreference = 'Stop'
Import-Module ([System.IO.Path]::GetFullPath([System.IO.Path]::Combine($PSScriptRoot, 'modules', 'Prerequisites.psm1'))) -Force
Initialize-RequiredModule -Name ImportExcel -InformationAction Continue
Add-Type -AssemblyName System.Drawing

# The standard sheets, in workbook order. Workspace sheets follow them and need no description.
$script:SheetCatalog = @(
    [pscustomobject]@{ Name = 'Summary'; Description = 'Run details, totals and links to every sheet' }
    [pscustomobject]@{ Name = 'All Lineage'; Description = 'Every report, semantic model, table and the source it reads from' }
    [pscustomobject]@{ Name = 'Source Objects'; Description = 'Each database object and the reports that depend on it' }
    [pscustomobject]@{ Name = 'Issues'; Description = 'Anything that could not be read during the run' }
)

$script:MaxCellLength = 32767
$script:TruncationMarker = ' ...[truncated in Excel; full text in the JSON]'
$script:TruncatedCells = 0

$script:ColumnTypes = @{
    TableIsHidden = [bool]
    ReportCount   = [int]
    ModelCount    = [int]
}

$script:ColumnWidths = @{
    WorkspaceName = 24; ReportName = 30; DatasetName = 28; DatasetWorkspaceName = 24; TableName = 26
    SourceType = 22; Connector = 20; Server = 34; Database = 24; Schema = 14; SourceObject = 30; Location = 40
    GatewayName = 24; GatewayDatasourceName = 24; ConnectionDetails = 40; IsSnowflakeConnection = 22; NativeQuery = 50; Notes = 60
    SourceExpression = 60; Reports = 60; ModelTables = 60; Gateways = 24; Area = 18; Item = 36; Message = 100
}

# Used when a run produced no rows, so the sheets still show their headers.
$script:DefaultLineageColumns = @(
    'WorkspaceName', 'WorkspaceId', 'ReportName', 'ReportId', 'ReportType', 'DatasetName', 'DatasetId',
    'DatasetWorkspaceName', 'DatasetWorkspaceId', 'DatasetStorageMode', 'TableName', 'TableIsHidden',
    'TableStorageMode', 'SourceType', 'Connector', 'Server', 'Database', 'Schema', 'SourceObject',
    'SourceObjectKind', 'ObjectOrigin', 'Location', 'ConnectorOptions', 'NativeQuery', 'DatasourceType',
    'GatewayId', 'GatewayName', 'GatewayDatasourceId', 'GatewayDatasourceName', 'ConnectionDetails', 'IsSnowflakeConnection', 'Notes',
    'SourceExpression')
$script:DefaultSourceObjectColumns = @(
    'SourceType', 'Server', 'Database', 'Schema', 'SourceObject', 'Location', 'Gateways', 'ReportCount',
    'ModelCount', 'Reports', 'ModelTables')
$script:DefaultIssueColumns = @('Area', 'Item', 'Message')

function ConvertTo-CellText {
    param($Value)
    # ConvertFrom-Json turns ISO date strings into DateTime; write them back as the text they were.
    $text = if ($Value -is [string]) { $Value }
    elseif ($Value -is [datetime]) { $Value.ToString('yyyy-MM-ddTHH:mm:ss.FFFFFFFK') }
    elseif ($Value -is [ValueType]) { [string]$Value }
    else { ConvertTo-Json -InputObject $Value -Compress -Depth 10 }
    if ($text.Length -gt $script:MaxCellLength) {
        $script:TruncatedCells++
        $text = $text.Substring(0, $script:MaxCellLength - $script:TruncationMarker.Length) + $script:TruncationMarker
    }
    $text
}

function ConvertTo-DataTable {
    param([object[]] $Rows, [string[]] $DefaultColumns, [string] $TableName)
    $columns = if ($Rows.Count -gt 0) { @($Rows[0].PSObject.Properties.Name) } else { $DefaultColumns }

    $table = [System.Data.DataTable]::new($TableName)
    foreach ($column in $columns) {
        $type = if ($script:ColumnTypes.ContainsKey($column)) { $script:ColumnTypes[$column] } else { [string] }
        [void]$table.Columns.Add($column, $type)
    }

    $table.BeginLoadData()
    foreach ($row in $Rows) {
        $dataRow = $table.NewRow()
        foreach ($column in $columns) {
            $value = $row.$column
            if ($null -eq $value) { continue }
            if ($table.Columns[$column].DataType -eq [string]) { $dataRow[$column] = ConvertTo-CellText $value }
            elseif (-not ($value -is [string] -and $value.Length -eq 0)) { $dataRow[$column] = $value }
        }
        $table.Rows.Add($dataRow)
    }
    $table.EndLoadData()
    , $table
}

function Get-SheetName {
    # Excel sheet names: at most 31 characters, none of []:*?/\, not wrapped in quotes, unique ignoring case.
    param([string] $Name, [System.Collections.Generic.HashSet[string]] $Used)
    $clean = ($Name -replace '[\[\]:*?/\\]', '-').Trim().Trim("'").Trim()
    if (-not $clean) { $clean = 'Workspace' }
    if ($clean.Length -gt 31) { $clean = $clean.Substring(0, 31).TrimEnd() }

    $candidate = $clean
    for ($n = 2; $Used.Contains($candidate) -or $candidate -eq 'History'; $n++) {
        $suffix = " ($n)"
        $candidate = $clean.Substring(0, [math]::Min($clean.Length, 31 - $suffix.Length)).TrimEnd() + $suffix
    }
    [void]$Used.Add($candidate)
    $candidate
}

function Add-DataSheet {
    param($Package, [string] $SheetName, [System.Data.DataTable] $Table)
    $sheet = $Package.Workbook.Worksheets.Add($SheetName)
    if ($Table.Rows.Count -gt 0) {
        [void]$sheet.Cells['A1'].LoadFromDataTable($Table, $true, [OfficeOpenXml.Table.TableStyles]::Medium2)
    }
    else {
        [void]$sheet.Cells['A1'].LoadFromDataTable($Table, $true)
        $sheet.Row(1).Style.Font.Bold = $true
    }
    for ($i = 0; $i -lt $Table.Columns.Count; $i++) {
        $name = $Table.Columns[$i].ColumnName
        $width = if ($script:ColumnWidths.ContainsKey($name)) { $script:ColumnWidths[$name] } elseif ($name -like '*Id') { 38 } else { 18 }
        $sheet.Column($i + 1).Width = $width
    }
    $sheet.View.FreezePanes(2, 1)
    $sheet
}

function Set-SheetLink {
    param($Cell, [string] $SheetName)
    $Cell.Hyperlink = [OfficeOpenXml.ExcelHyperLink]::new("'$($SheetName.Replace("'", "''"))'!A1", $SheetName)
    $Cell.Value = $SheetName
    $Cell.Style.Font.UnderLine = $true
    $Cell.Style.Font.Color.SetColor([System.Drawing.Color]::FromArgb(5, 99, 193))
}

function Add-SummarySheet {
    param($Package, $Document, [object[]] $WorkspaceSheets)
    $sheet = $Package.Workbook.Worksheets.Add('Summary')
    $sheet.Cells['A1'].Value = 'Power BI report lineage'
    $sheet.Cells['A1'].Style.Font.Bold = $true
    $sheet.Cells['A1'].Style.Font.Size = 14

    $scope = if ($Document.workspaceScope -is [string]) { $Document.workspaceScope } else { @($Document.workspaceScope) -join ', ' }
    $details = [ordered]@{
        'Generated (UTC)'                = ConvertTo-CellText $Document.generatedAtUtc
        'Collection mode'                = $Document.collectionMode
        'Signed in as'                   = $Document.signedInAs
        'Workspace scope'                = $scope
        'Workspaces with reports'        = $Document.summary.workspaces
        'Reports'                        = $Document.summary.reports
        'Semantic models'                = $Document.summary.semanticModels
        'Lineage rows'                   = $Document.summary.lineageRows
        'Traced to a source object'      = $Document.summary.tracedToObject
        'Traced to a connection only'    = $Document.summary.connectionOnly
        'No external source'             = $Document.summary.noExternalSource
        'Issues'                         = @($Document.issues | Where-Object { $_ }).Count
        'Source JSON'                    = (Resolve-Path $JsonPath).Path
    }
    $r = 3
    foreach ($entry in $details.GetEnumerator()) {
        $sheet.Cells[$r, 1].Value = $entry.Key
        $sheet.Cells[$r, 1].Style.Font.Bold = $true
        $sheet.Cells[$r, 2].Value = $entry.Value
        $r++
    }
    if ($script:TruncatedCells -gt 0) {
        $sheet.Cells[$r, 1].Value = 'Truncated cells'
        $sheet.Cells[$r, 1].Style.Font.Bold = $true
        $sheet.Cells[$r, 2].Value = "$($script:TruncatedCells) value(s) exceeded Excel's 32,767-character cell limit and are cut here; the JSON has the full text."
        $r++
    }

    $r++
    $sheet.Cells[$r, 1].Value = 'Sheet'
    $sheet.Cells[$r, 2].Value = 'Contents'
    $sheet.Row($r).Style.Font.Bold = $true
    foreach ($entry in $script:SheetCatalog) {
        $r++
        Set-SheetLink $sheet.Cells[$r, 1] $entry.Name
        $sheet.Cells[$r, 2].Value = $entry.Description
    }

    $r += 2
    $headers = 'Workspace', 'Sheet', 'Reports', 'Semantic models', 'Lineage rows', 'Traced to a source object'
    for ($c = 1; $c -le $headers.Count; $c++) { $sheet.Cells[$r, $c].Value = $headers[$c - 1] }
    $sheet.Row($r).Style.Font.Bold = $true
    foreach ($workspace in $WorkspaceSheets) {
        $r++
        $sheet.Cells[$r, 1].Value = $workspace.Name
        Set-SheetLink $sheet.Cells[$r, 2] $workspace.Sheet
        $sheet.Cells[$r, 3].Value = $workspace.Reports
        $sheet.Cells[$r, 4].Value = $workspace.Models
        $sheet.Cells[$r, 5].Value = $workspace.Rows
        $sheet.Cells[$r, 6].Value = $workspace.Traced
    }
    $sheet.Column(1).Width = 30
    $sheet.Column(2).Width = 34
    foreach ($c in 3..6) { $sheet.Column($c).Width = 18 }
}

if (-not (Test-Path -LiteralPath $JsonPath)) { throw "JSON file not found: $JsonPath" }
if (Test-Path -LiteralPath $ExcelPath) {
    if (-not $Force) { throw "$ExcelPath already exists. Use -Force to replace it." }
    Remove-Item -LiteralPath $ExcelPath -Force
}
$directory = Split-Path -Parent ([System.IO.Path]::GetFullPath($ExcelPath))
if (-not (Test-Path -LiteralPath $directory)) { $null = New-Item -ItemType Directory -Path $directory -Force }

$json = Get-Content -Raw -LiteralPath $JsonPath -Encoding UTF8
$document = if ($PSVersionTable.PSVersion.Major -ge 7) { $json | ConvertFrom-Json -Depth 100 } else { $json | ConvertFrom-Json }
if ($document.schemaVersion -ne 1) { throw "Unsupported lineage JSON schemaVersion '$($document.schemaVersion)'." }

$lineage = @($document.lineage | Where-Object { $_ })
$allTable = ConvertTo-DataTable $lineage $script:DefaultLineageColumns 'AllLineage'
$sourceTable = ConvertTo-DataTable @($document.sourceObjects | Where-Object { $_ }) $script:DefaultSourceObjectColumns 'SourceObjects'
$issueTable = ConvertTo-DataTable @($document.issues | Where-Object { $_ }) $script:DefaultIssueColumns 'Issues'

$usedNames = [System.Collections.Generic.HashSet[string]]::new([System.StringComparer]::OrdinalIgnoreCase)
foreach ($reserved in $script:SheetCatalog.Name) { [void]$usedNames.Add($reserved) }

$workspaceSheets = @($lineage | Group-Object WorkspaceId | ForEach-Object {
        $rows = $_.Group
        $name = ($rows | Where-Object WorkspaceName | Select-Object -First 1).WorkspaceName
        if (-not $name) { $name = $_.Name }
        [pscustomobject]@{
            Id      = $_.Name
            Name    = $name
            Reports = @($rows.ReportId | Sort-Object -Unique).Count
            Models  = @($rows.DatasetId | Where-Object { $_ } | Sort-Object -Unique).Count
            Rows    = $rows.Count
            Traced  = @($rows | Where-Object SourceObject).Count
            Sheet   = $null
        }
    } | Sort-Object Name, Id)
foreach ($workspace in $workspaceSheets) { $workspace.Sheet = Get-SheetName $workspace.Name $usedNames }

$package = Open-ExcelPackage -Path $ExcelPath -Create
try {
    Add-SummarySheet $package $document $workspaceSheets
    $null = Add-DataSheet $package 'All Lineage' $allTable
    $null = Add-DataSheet $package 'Source Objects' $sourceTable
    $null = Add-DataSheet $package 'Issues' $issueTable

    $view = [System.Data.DataView]::new($allTable)
    $index = 0
    foreach ($workspace in $workspaceSheets) {
        $index++
        Write-Progress -Activity 'Building workspace sheets' -Status $workspace.Name -PercentComplete ([int](100 * $index / $workspaceSheets.Count))
        $view.RowFilter = "WorkspaceId = '$($workspace.Id.Replace("'", "''"))'"
        $null = Add-DataSheet $package $workspace.Sheet $view.ToTable("Workspace$index")
    }
    Write-Progress -Activity 'Building workspace sheets' -Completed
}
catch {
    Close-ExcelPackage $package -NoSave
    throw
}
Close-ExcelPackage $package

Write-Verbose "Workbook written: $ExcelPath ($($workspaceSheets.Count) workspace sheet(s), $($script:TruncatedCells) truncated cell(s))."

# Describe what was built, so callers can report it.
[pscustomobject]@{
    Path            = (Resolve-Path -LiteralPath $ExcelPath).Path
    Sheets          = $script:SheetCatalog
    WorkspaceSheets = @($workspaceSheets.Sheet)
    TruncatedCells  = $script:TruncatedCells
}
'@

# ==== File 8 of 8: Invoke-LineageRun.ps1 (29 lines) =============================================================
$files['Invoke-LineageRun.ps1'] = @'
#Requires -Version 5.1
<#
.SYNOPSIS
    Runs Get-PbiReportLineage.ps1 unattended with settings taken from LINEAGE_* environment variables.

.DESCRIPTION
    Used by PowerBI-Lineage.Orchestrator.ps1. Reading the settings from environment variables means no value typed into
    the runbook is ever placed on a command line. On failure it writes "ERROR: <message>" to standard error and exits 1.
#>

$ErrorActionPreference = 'Stop'
try {
    $parameters = @{
        Unattended = $true
        Mode       = $env:LINEAGE_MODE
        TenantId   = $env:LINEAGE_TENANT_ID
        ClientId   = $env:LINEAGE_CLIENT_ID
        ExcelPath  = $env:LINEAGE_EXCEL_PATH
    }
    if ($env:LINEAGE_CERTIFICATE_THUMBPRINT) { $parameters.CertificateThumbprint = $env:LINEAGE_CERTIFICATE_THUMBPRINT }
    if ($env:LINEAGE_WORKSPACE_IDS) { $parameters.WorkspaceId = @($env:LINEAGE_WORKSPACE_IDS -split ',') }

    & (Join-Path $PSScriptRoot 'src\Get-PbiReportLineage.ps1') @parameters
    exit 0
}
catch {
    [Console]::Error.WriteLine("ERROR: $($_.Exception.Message)")
    exit 1
}
'@

# ---- Save the tool once per version ----------------------------------------------------------------------------

$newLine = [string][char]13 + [char]10
$allFiles = @($files.Keys | ForEach-Object { $_ + $newLine + $files[$_] }) -join $newLine
$sha = [Security.Cryptography.SHA256]::Create()
$version = -join (@($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes($allFiles)))[0..5] | ForEach-Object { $_.ToString('x2') })

$installRoot = Join-Path $env:ProgramData 'PowerBI-Lineage'
try { $null = New-Item -ItemType Directory -Path $installRoot -Force }
catch { $installRoot = Join-Path ([IO.Path]::GetTempPath()) 'PowerBI-Lineage' }
$target = Join-Path $installRoot $version

if (-not (Test-Path -LiteralPath (Join-Path $target '.complete'))) {
    foreach ($name in $files.Keys) {
        $path = Join-Path $target $name
        $null = New-Item -ItemType Directory -Path (Split-Path -Parent $path) -Force
        $content = ($files[$name] -replace "(?m)^#~'@", "'@") -replace '\r?\n', $newLine
        [IO.File]::WriteAllText($path, $content + $newLine, (New-Object System.Text.UTF8Encoding -ArgumentList $true))
    }
    Set-Content -LiteralPath (Join-Path $target '.complete') -Value $version
    # Remove older versions only: their folder names are 12 hex characters.
    Get-ChildItem -LiteralPath $installRoot | Where-Object { $_.PSIsContainer -and $_.Name -match '^[0-9a-f]{12}$' -and $_.Name -ne $version } |
        Remove-Item -Recurse -Force -ErrorAction SilentlyContinue
}
# ---- Run in 64-bit Windows PowerShell --------------------------------------------------------------------------
# Orchestrator runs this script in 32-bit PowerShell; Sysnative reaches the 64-bit system folder from there.
# Settings are passed as environment variables, so no value is ever part of a command line.

$system = Join-Path $env:SystemRoot 'Sysnative'
if (-not (Test-Path -LiteralPath $system)) { $system = Join-Path $env:SystemRoot 'System32' }
# This path is resolved by the 64-bit cmd.exe started below, for which Sysnative does not exist: use System32.
$powershell = Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'
$runner = Join-Path $target 'Invoke-LineageRun.ps1'

$runId = [guid]::NewGuid().ToString('N')
$stdoutFile = Join-Path ([IO.Path]::GetTempPath()) ('PowerBI-Lineage-' + $runId + '.out.txt')
$stderrFile = Join-Path ([IO.Path]::GetTempPath()) ('PowerBI-Lineage-' + $runId + '.err.txt')

$startInfo = New-Object System.Diagnostics.ProcessStartInfo
$startInfo.FileName = Join-Path $system 'cmd.exe'
$startInfo.Arguments = '/d /c ""' + $powershell + '" -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "' + $runner +
    '" > "' + $stdoutFile + '" 2> "' + $stderrFile + '" < NUL"'
$startInfo.WorkingDirectory = $target
$startInfo.UseShellExecute = $false
$startInfo.CreateNoWindow = $true
$settings = @{
    LINEAGE_TENANT_ID              = $TenantId
    LINEAGE_CLIENT_ID              = $AppId
    LINEAGE_EXCEL_PATH             = $ExcelPath
    LINEAGE_MODE                   = $Mode
    LINEAGE_WORKSPACE_IDS          = $WorkspaceIds
    LINEAGE_CERTIFICATE_THUMBPRINT = $CertificateThumbprint
    PBI_CLIENT_SECRET              = $ClientSecret
}
foreach ($name in $settings.Keys) {
    if ($settings[$name]) { $startInfo.EnvironmentVariables[$name] = $settings[$name] }
    elseif ($startInfo.EnvironmentVariables.ContainsKey($name)) { $startInfo.EnvironmentVariables.Remove($name) }
}
# A PowerShell 7 host (.NET 8) passes on its own module folders, whose built-in modules do not load in Windows
# PowerShell: keep them out. The tool still finds modules installed for PowerShell 7 if nothing else has them.
$modulePath = @("$env:PSModulePath" -split ';' | Where-Object { $_ -and $_ -notmatch '\\PowerShell\\' }) -join ';'
if ($modulePath) { $startInfo.EnvironmentVariables['PSModulePath'] = $modulePath }
elseif ($startInfo.EnvironmentVariables.ContainsKey('PSModulePath')) { $startInfo.EnvironmentVariables.Remove('PSModulePath') }
if (-not $startInfo.EnvironmentVariables['LOCALAPPDATA']) {
    $startInfo.EnvironmentVariables['LOCALAPPDATA'] = Join-Path $installRoot 'LocalAppData'
}

$process = [System.Diagnostics.Process]::Start($startInfo)
$finished = $process.WaitForExit($timeout * 60 * 1000)
if (-not $finished) { & taskkill.exe /PID $process.Id /T /F | Out-Null }

$output = ''
$errorText = ''
if (Test-Path -LiteralPath $stdoutFile) { $output = [IO.File]::ReadAllText($stdoutFile); Remove-Item -LiteralPath $stdoutFile -Force }
if (Test-Path -LiteralPath $stderrFile) { $errorText = [IO.File]::ReadAllText($stderrFile); Remove-Item -LiteralPath $stderrFile -Force }

# Orchestrator does not keep the activity's console output, so the run log is saved next to the workbook.
$logPath = [IO.Path]::ChangeExtension($ExcelPath, '.log')
try {
    $logFolder = Split-Path -Parent $logPath
    if ($logFolder -and -not (Test-Path -LiteralPath $logFolder)) { $null = New-Item -ItemType Directory -Path $logFolder -Force }
    [IO.File]::WriteAllText($logPath, ($output + $errorText))
}
catch { $logPath = '(log not written: ' + $_.Exception.Message + ')' }

if (-not $finished) { throw "Power BI lineage run did not finish within $timeout minutes and was stopped. Log: $logPath" }
if ($process.ExitCode -ne 0) {
    $reason = (($errorText -replace '\s+', ' ').Trim()) -replace '^ERROR:\s*', ''
    if (-not $reason) { $reason = (@($output -split '\r?\n' | Where-Object { $_ -match '\S' }) | Select-Object -Last 5) -join ' ' }
    throw "Power BI lineage run failed: $reason Log: $logPath"
}

# Success: the run summary.
$output
